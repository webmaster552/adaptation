# IA locale de cette version

Le serveur utilise Ollama sur le Mac à l’adresse `127.0.0.1:11434`.
Aucun abonnement ni clé d’IA n’est nécessaire. Aucun modèle n’est déployé sur Render.

- `qwen3.5:4b` : photos, échanges courants, conseils, fiches et première rédaction des entraînements.
- `qwen2.5-coder:14b` : outils de préparation du professeur, quiz, explications de cours, demandes dont la matière indique français/histoire/philosophie, et résolution indépendante des corrigés d’entraînement.

Le routage conserve le modèle d’origine pour les préparations où les essais du petit modèle ont montré davantage d’erreurs. La génération ne devient pas une banque de réponses préécrites. Les réponses et transcriptions restent à relire.

Les modèles sont maintenus en mémoire jusqu’à dix minutes d’inactivité ; Ollama peut les décharger pour libérer de la mémoire. Une seule préparation est exécutée à la fois. La progression affichée correspond aux étapes réelles, sans pourcentage inventé.

Les textes des documents sélectionnés ne sont plus coupés à 2 000 caractères dans la conversation locale. Le budget de contexte augmente pour les dossiers longs ; un dépassement est signalé plutôt que tronqué silencieusement.

Les photos identiques bénéficient d’un cache local de transcription pendant dix minutes, limité à 16 entrées. Ce cache ne contient pas les réponses de conversation. Il est purgé à l’arrêt du serveur. Les petites images originales sont préservées ; les grandes photos sont redimensionnées jusqu’à 2 600 pixels, avec compression limitée.

Les modèles sont déjà installés sur le Mac d’origine. Sur un autre ordinateur, voir LISEZ-MOI.txt. Le premier chargement, les longs supports et les écritures difficiles peuvent rester plus lents. Les mesures réelles sont dans VERIFICATIONS-LOCALES.txt.
