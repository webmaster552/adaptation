import test from 'node:test';
import assert from 'node:assert/strict';
import {teacherReview,teacherObservations,compareTeacherPriority} from '../dist/teacher-view.mjs';
const pupil=(m={},extra={})=>({grades:[],m:{current:14,previous:14,absenceHalfDays:0,lates:0,...m},...extra});

test('teacher view does not derive averages from individual grades',()=>{
  const review=teacherReview(pupil({current:null,previous:null},{grades:[{value:2,outOf:20}]}));
  assert.deepEqual(review.facts,[]);assert.equal(review.level,'missing');assert.equal(review.needsFollowup,false);
});
test('published decrease is explained with its actual values',()=>{
  assert.deepEqual(teacherObservations(pupil({current:8,previous:14})),['Moyenne publiée en baisse : 14 → 8/20.']);
});
test('missing absence duration preserves the event count without conversion',()=>{
  const review=teacherReview(pupil({current:null,absenceHalfDays:null,lates:3},{attendance:{absenceEvents:2}}));
  assert.match(review.facts.join(' '),/2 absences non justifiées ; durée non transmise/);
  assert.match(review.facts.join(' '),/3 retards/);assert.equal(review.level,'watch');
});
test('justified absences alone do not trigger an alert',()=>{
  assert.deepEqual(teacherObservations(pupil({lates:1},{attendance:{justifiedHalfDays:8,absenceEvents:0}})),[]);
});
test('explicit fractional half days are preserved',()=>{
  assert.match(teacherObservations(pupil({absenceHalfDays:.5}))[0],/0,5 demi-journée non justifiée/);
});
test('marked decline with absences comes before a single mild signal',()=>{
  const severe=pupil({current:9,previous:14,absenceHalfDays:2},{lastName:'Zulu'});
  const mild=pupil({current:12,previous:14},{lastName:'Albert'});
  assert.equal(teacherReview(severe).level,'high');assert.equal(teacherReview(mild).level,'watch');
  assert.equal([mild,severe].sort(compareTeacherPriority)[0],severe);
});
test('repeated attendance signals can trigger priority without published averages',()=>{
  const review=teacherReview(pupil({current:null,previous:null,absenceHalfDays:4}));
  assert.equal(review.level,'high');assert.equal(review.missing.length,2);
  assert.equal(teacherReview(pupil({lates:5})).level,'high');
});
test('combining weak results, absences and repeated lateness raises suggested priority',()=>{
  assert.equal(teacherReview(pupil({current:9,previous:10,absenceHalfDays:1,lates:3})).level,'high');
  assert.equal(teacherReview(pupil({current:9,previous:10,absenceHalfDays:1,lates:2})).level,'watch');
});
test('a weak published subject is visible even with a satisfactory general average',()=>{
  const review=teacherReview(pupil({}, {reportPeriods:[{id:'p',start:'2026-09-01',end:'2026-12-01',average:14,subjects:[{subject:'Hébreu',average:8.5}]}]}));
  assert.equal(review.level,'watch');assert.match(review.facts[0],/Hébreu : moyenne publiée de 8,5/);
  assert.match(review.hypotheses[0],/piste à vérifier/);
});
test('explanations distinguish observations and possible links without invented causes',()=>{
  const review=teacherReview(pupil({current:9,previous:14,absenceHalfDays:2}));
  assert.match(review.hypotheses[0],/peuvent/);assert.match(review.hypotheses[0],/Vérifier/);
  assert.doesNotMatch(JSON.stringify(review),/dépress|famill|paresse|échec|probabilité/i);
  assert.ok(review.nextStep);assert.equal('score' in review,false);
});
test('equal priorities use names, and names never affect the explanation',()=>{
  const a=pupil({current:9},{lastName:'Zulu',firstName:'Adam'}),b={...a,lastName:'Albert',firstName:'Zoé'};
  assert.deepEqual(teacherReview(a),teacherReview(b));assert.equal([a,b].sort(compareTeacherPriority)[0],b);
});
test('stable complete data remain separate from missing data',()=>{
  assert.equal(teacherReview(pupil()).level,'none');
  assert.equal(teacherReview(pupil({current:null,previous:null,lates:null,absenceHalfDays:null})).level,'missing');
});
