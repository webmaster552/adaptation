import test from 'node:test';
import assert from 'node:assert/strict';
import {establishmentName,photoAddress} from '../server/identity.mjs';
import {EcoleDirecteConnector} from '../server/connector.mjs';
import {makeFixtureFetch,testNow} from './fixtures.mjs';
test('Établissement provenant du profil et champs vides traités explicitement',()=>{
 assert.equal(establishmentName({nomEtablissement:' ',profile:{nomEtablissement:'Collège Réel'}}),'Collège Réel');assert.equal(establishmentName({nomEtablissement:{nom:'inconnu'}}),'');
});
test('Photo : adresses ÉcoleDirecte uniquement, pas de port, identifiants ni faux domaine',()=>{
 assert.equal(photoAddress('//doc1.ecoledirecte.com/PhotoEleves/fixture.png'),'https://doc1.ecoledirecte.com/PhotoEleves/fixture.png');assert.equal(photoAddress('/PhotoEleves/test.png'),'https://api.ecoledirecte.com/PhotoEleves/test.png');
 for(const url of ['http://doc1.ecoledirecte.com/a','https://ecoledirecte.com.evil.example/a','https://user:pass@doc1.ecoledirecte.com/a','https://doc1.ecoledirecte.com:8080/a','data:image/svg+xml,test'])assert.equal(photoAddress(url),null);
});
test('Profil enrichi : photo et établissement du compte sans données personnelles supplémentaires',async()=>{
 const fixture=makeFixtureFetch({profileSchool:true,profilePhoto:true});const connector=new EcoleDirecteConnector({...fixture,now:testNow});const login=await connector.login('test','fictif');assert.equal(login.account.establishment,'Collège du Profil');
 const data=await connector.sync();assert.equal(data.account.studentId,'ed-42');assert.equal(data.students[0].photoUrl,'/api/photo/ed-42');assert.equal(data.account.photoUrl,'/api/photo/ed-42');assert.equal(data.students[0].establishment,'Collège du Profil');
 const image=await connector.photo('ed-42');assert.equal(image.type,'image/png');assert.ok(image.bytes.length>0);const request=fixture.calls.at(-1);assert.equal(request.options.headers['X-Token'],undefined);assert.equal(request.options.redirect,'manual');
 connector.clear();await assert.rejects(connector.photo('ed-42'),{code:'NO_PHOTO'});
});
test('Un profil d’un autre identifiant ne remplace jamais le dossier courant',async()=>{
 const fixture=makeFixtureFetch({profileSchool:true,profilePhoto:true});const connector=new EcoleDirecteConnector({now:testNow,fetchImpl:async(url,opts)=>url.includes('/eleves/42.awp')?new Response(JSON.stringify({code:200,data:{id:999,prenom:'Intrus',nom:'Autre',photo:'//doc1.ecoledirecte.com/other.jpg'}})):fixture.fetchImpl(url,opts)});
 await connector.login('test','fictif');const data=await connector.sync();assert.equal(data.students[0].id,'ed-42');assert.notEqual(data.students[0].firstName,'Intrus');assert.equal(data.students[0].photoUrl,undefined);
});
