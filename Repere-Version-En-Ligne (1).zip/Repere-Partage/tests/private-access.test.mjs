import test from 'node:test';
import http from 'node:http';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {createPrivateServer,configuredUsers} from '../server/private-access.mjs';
import {createAppServer} from '../server.mjs';
import {EcoleDirecteConnector} from '../server/connector.mjs';
import {makeFixtureFetch,testNow} from './fixtures.mjs';
const origin='https://repere.example',users=[{name:'proprietaire',password:'mot-de-passe-fictif-un-2026'},{name:'ami',password:'mot-de-passe-fictif-deux-2026'}];
async function start(t,{clock=()=>Date.now()}={}){
 const server=await createPrivateServer({origin,users,now:clock,appFactory:()=>createAppServer({connectorFactory:()=>new EcoleDirecteConnector({...makeFixtureFetch(),now:testNow})})});server.listen(0,'127.0.0.1');await once(server,'listening');t.after(()=>new Promise(r=>{server.closeAllConnections();server.close(r);}));
 const base='http://127.0.0.1:'+server.address().port;
 const call=(path,{method='GET',body,cookie='',headers={}}={})=>new Promise((resolve,reject)=>{
  const req=http.request(base+path,{method,headers:{Host:new URL(origin).host,...(method==='POST'?{Origin:origin}:{}),...(cookie?{Cookie:cookie}:{}),...headers}},response=>{
   const chunks=[];response.on('data',c=>chunks.push(c));response.on('end',()=>{const resultHeaders=new Headers();for(let i=0;i<response.rawHeaders.length;i+=2)resultHeaders.append(response.rawHeaders[i],response.rawHeaders[i+1]);resolve(new Response(Buffer.concat(chunks),{status:response.statusCode,headers:resultHeaders}));});
  });req.on('error',reject);req.end(body);
 });
 const login=async(user=users[0])=>{const response=await call('/private/login',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({username:user.name,password:user.password}).toString()});return {response,cookie:response.headers.getSetCookie().find(c=>c.startsWith('__Host-'))?.split(';')[0]};};
 return {call,login};
}
test('Render refuse une configuration ouverte ou des comptes identiques',()=>{
 assert.throws(()=>configuredUsers({}));assert.throws(()=>configuredUsers({REPERE_USER_1:'x',REPERE_PASSWORD_1:users[0].password,REPERE_USER_2:'x',REPERE_PASSWORD_2:users[1].password}));
 assert.throws(()=>configuredUsers({REPERE_USER_1:'x',REPERE_PASSWORD_1:'court',REPERE_USER_2:'y',REPERE_PASSWORD_2:users[1].password}));
});
test('Site et API entièrement protégés avant connexion, santé sans données',async t=>{
 const {call}=await start(t);
 for(const path of ['/','/app.js','/index.html','/assets/portraits-fictifs.png','/server.mjs','//index.html']){const r=await call(path);assert.equal(r.status,303);assert.equal(r.headers.get('location'),'/private/login');}
 assert.equal((await call('/api/session')).status,401);assert.equal(await(await call('/healthz')).text(),'ok');
 const page=await call('/private/login');assert.equal(page.status,200);assert.match(await page.text(),/Votre espace privé/);assert.equal(page.headers.get('cache-control'),'no-store');
});
test('Deux connexions valides, cookie sécurisé, mots de passe absents de la page',async t=>{
 const {call,login}=await start(t);
 for(const user of users){const {response,cookie}=await login(user);assert.equal(response.status,303);assert.ok(cookie);assert.match(response.headers.get('set-cookie'),/HttpOnly/);assert.match(response.headers.get('set-cookie'),/Secure/);assert.match(response.headers.get('set-cookie'),/SameSite=Strict/);
 const page=await call('/',{cookie});assert.equal(page.status,200);const html=await page.text();assert.match(html,/Quitter l’espace privé/);assert.ok(!html.includes(user.password));assert.equal((await call('/app.js',{cookie})).status,200);
 assert.equal((await call('/server.mjs',{cookie})).status,404);assert.equal((await call('/render.yaml',{cookie})).status,404);}
});
test('Mot de passe invalide et cookie fabriqué ne donnent pas accès',async t=>{
 const {call,login}=await start(t);assert.equal((await login({...users[0],password:'erreur'})).response.status,401);assert.equal((await login({name:'inconnu',password:users[0].password})).response.status,401);
 assert.equal((await call('/api/session',{cookie:'__Host-repere_access=fabrique'})).status,401);
});
test('Origine et hôte étrangers rejetés, corps trop long refusé',async t=>{
 const {call,login}=await start(t);const {cookie}=await login();
 assert.equal((await call('/api/login',{method:'POST',cookie,headers:{Origin:'https://intrus.example','Content-Type':'application/json'},body:'{}'})).status,403);
 assert.equal((await call('/',{cookie,headers:{Host:'intrus.example','X-Forwarded-Host':'repere.example'}})).status,403);
 assert.equal((await call('/private/login',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'x'.repeat(9000)})).status,413);
});
test('Les sessions ÉcoleDirecte ne passent pas d’un compte privé à l’autre',async t=>{
 const {call,login}=await start(t),a=await login(),b=await login(users[1]);
 const r=await call('/api/login',{method:'POST',cookie:a.cookie,headers:{'Content-Type':'application/json','X-Repere-Request':'1'},body:JSON.stringify({username:'fictif',password:'fictif'})});assert.equal(r.status,200);
 const schoolCookie=r.headers.getSetCookie().find(c=>c.startsWith('repere_session='))?.split(';')[0];assert.ok(schoolCookie);assert.match(r.headers.get('set-cookie'),/Secure/);
 assert.equal((await(await call('/api/session',{cookie:a.cookie+'; '+schoolCookie})).json()).status,'authenticated');
 assert.equal((await(await call('/api/session',{cookie:b.cookie+'; '+schoolCookie})).json()).status,'disconnected');
});
test('Déconnexion invalide le jeton, expiration ferme également l’accès',async t=>{
 let time=Date.now();const {call,login}=await start(t,{clock:()=>time});const {cookie}=await login();
 assert.equal((await call('/private/logout',{cookie})).status,405);
 assert.equal((await call('/private/logout',{method:'POST',cookie})).status,303);assert.equal((await call('/api/session',{cookie})).status,401);
 const renewed=await login();time+=8*60*60*1000+1;assert.equal((await call('/api/session',{cookie:renewed.cookie})).status,401);
});
test('Limite des essais de connexion',async t=>{
 const {login}=await start(t);for(let i=0;i<10;i++)assert.equal((await login({...users[0],password:'erreur'})).response.status,401);
 const blocked=(await login({...users[0],password:'erreur'})).response;assert.equal(blocked.status,429);assert.equal(blocked.headers.get('retry-after'),'600');
});
