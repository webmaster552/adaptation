import test from 'node:test';
import assert from 'node:assert/strict';
import {EcoleDirecteConnector} from '../server/connector.mjs';
import {windows,normalizeGrades,normalizeAttendance,halfDays,number,dateOnly} from '../server/normalize.mjs';
import {evaluate,metricsFor} from '../dist/engine.mjs';
import {testNow,notes,life,makeFixtureFetch} from './fixtures.mjs';
const periods=windows(testNow());
test('Périodes de 28 jours calculées en heure de Paris et dates strictes',()=>{
 assert.deepEqual(periods,{previousStart:'2026-08-25',previousEnd:'2026-09-21',recentStart:'2026-09-22',recentEnd:'2026-10-19'});
 assert.equal(dateOnly('2026-02-30'),null);assert.equal(number(''),null);assert.equal(number(null),null);assert.equal(number('14,5'),14.5);
});
test('Demi-journées explicites, dédoublonnage et exclusion des absences justifiées',()=>{
 assert.deepEqual(normalizeAttendance({...life,absencesRetards:[...life.absencesRetards,life.absencesRetards[0]]},periods),{absenceHalfDays:2,justifiedHalfDays:1,lates:1,warnings:[]});
 assert.equal(halfDays({libelle:'4 heures'}),null);assert.equal(halfDays({nbDemiJournees:'3'}),3);assert.equal(halfDays({nbDemiJournees:1.5}),null);
});
test('Absences ambiguës et événements chevauchant une période ne donnent pas zéro',()=>{
 for(const extra of [{libelle:'4 heures'},{justifie:null},{date:'inconnue'},{date:'2026-09-21',dateFin:'2026-09-23',libelle:'4 demi-journées'}]){
  const result=normalizeAttendance({absencesRetards:[{...life.absencesRetards[0],...extra}]},periods);assert.equal(result.absenceHalfDays,null);assert.ok(result.warnings.length);
 }
 assert.equal(normalizeAttendance(null,periods).absenceHalfDays,null);
 assert.equal(normalizeAttendance({absencesRetards:[]},periods).absenceHalfDays,0);
});
test('Notes absentes, barèmes et coefficients invalides ne deviennent pas des zéros',()=>{
 const result=normalizeGrades({notes:[...notes.notes,notes.notes[0],{id:9,valeur:'Abs'},{...notes.notes[0],id:10,coef:''},{...notes.notes[0],id:11,nonSignificatif:true}]},periods);
 assert.equal(result.grades.length,9);assert.equal(result.grades.find(g=>g.id==='9').value,null);assert.equal(result.grades.find(g=>g.id==='10').weight,null);assert.equal(result.grades.find(g=>g.id==='11').significant,false);assert.equal(result.grades.filter(g=>g.period==='recent').length,3);
});
test('Compte élève limité à son propre identifiant, secrets jamais retournés',async()=>{
 const {fetchImpl,calls}=makeFixtureFetch();const connector=new EcoleDirecteConnector({fetchImpl,now:testNow});
 const login=await connector.login('test-local','test-fictif');assert.equal(login.account.role,'student');assert.equal(connector.pending,null);
 const data=await connector.sync();assert.equal(data.students.length,1);assert.equal(data.students[0].id,'ed-42');assert.equal(evaluate(metricsFor(data.students[0])).score,null);
 assert.ok(calls.filter(c=>c.url.pathname.includes('/eleves/')).every(c=>/\/42(?:\/|\.awp$)/.test(c.url.pathname)));
 const loginCall=calls.find(c=>c.data?.identifiant);assert.equal(loginCall.options.headers['X-GTK'],'fixture-gtk');assert.equal(loginCall.options.redirect,'manual');
 assert.ok(!JSON.stringify([login,data]).includes('fixture-secret-token'));assert.ok(!JSON.stringify(data).includes('motdepasse'));
});
test('Professeur : listes autorisées, dédoublonnage classe/groupe, photo externe rejetée',async()=>{
 const {fetchImpl,calls}=makeFixtureFetch({teacher:true});const connector=new EcoleDirecteConnector({fetchImpl,now:testNow});
 await connector.login('test-local','test-fictif');const data=await connector.sync();assert.equal(data.students.length,2);assert.equal(data.account.role,'teacher');assert.equal(data.students[0].photoUrl,undefined);
 const classCalls=calls.filter(c=>c.url.pathname.includes('/classes/'));assert.equal(classCalls.length,1);assert.equal(classCalls[0].url.hostname,'apip.ecoledirecte.com');
 await assert.rejects(connector.photo('ed-999'),{code:'NO_PHOTO'});
});
test('Vérification question explicite et réponse choisie par utilisateur',async()=>{
 const {fetchImpl,calls}=makeFixtureFetch({challenge:'question'});const connector=new EcoleDirecteConnector({fetchImpl,now:testNow});
 const q=await connector.login('test-local','test-fictif');assert.deepEqual(q.choices,['Oui','Non']);
 await assert.rejects(connector.challenge({choice:9}),{code:'INVALID_CHOICE'});
 assert.equal((await connector.challenge({choice:0})).status,'authenticated');assert.equal(connector.pending,null);
 assert.equal(calls.filter(c=>c.data?.identifiant).at(-1).data.fa[0].cv,'fixture-cv');
});
test('Code TOTP vérifié avant envoi ; mot de passe retiré après authentification',async()=>{
 const {fetchImpl,calls}=makeFixtureFetch({challenge:'totp'});const connector=new EcoleDirecteConnector({fetchImpl,now:testNow});
 assert.equal((await connector.login('test-local','test-fictif')).type,'totp');await assert.rejects(connector.challenge({code:'123'}),{code:'INVALID_CODE'});
 await connector.challenge({code:'123456'});assert.deepEqual(calls.filter(c=>c.data?.identifiant).at(-1).data.fa,[{cn:'',cv:'123456'}]);assert.equal(connector.pending,null);
});
test('Refus de connexion explicite et absence de conservation des identifiants',async()=>{
 const connector=new EcoleDirecteConnector({...makeFixtureFetch({denied:true}),now:testNow});await assert.rejects(connector.login('test-local','test-fictif'),{code:'ED_505'});assert.equal(connector.pending,null);assert.equal(connector.token,'');
});
test('Import partiel sans remplacer les données absentes par la démonstration',async()=>{
 const connector=new EcoleDirecteConnector({...makeFixtureFetch({failAttendance:true}),now:testNow});await connector.login('test-local','test-fictif');const data=await connector.sync();assert.equal(data.students[0].attendance.absenceHalfDays,null);assert.equal(evaluate(metricsFor(data.students[0])).score,null);assert.ok(data.students[0].warnings.length);
});
test('Déconnexion annule une réponse en cours avant récupération des secrets',async()=>{
 let resolve;const connector=new EcoleDirecteConnector({fetchImpl:()=>new Promise(r=>{resolve=r;})});const pending=connector.request('login.awp',{data:{}});connector.clear();resolve(new Response(JSON.stringify({code:200,token:'late-secret'})));await assert.rejects(pending,{code:'SESSION_CLOSED'});assert.equal(connector.token,'');
});

test('Reprise de question : les jetons tournants et les facteurs acceptés sont conservés',async()=>{
 const fixture=makeFixtureFetch({challenge:'question'});let loginCount=0,gtkCount=0;
 const fetchImpl=async(url,options)=>{
  const u=new URL(url),data=options.body?JSON.parse(new URLSearchParams(options.body).get('data')):{};
  if(u.pathname==='/v3/login.awp'&&options.method==='GET'){
   gtkCount++;if(gtkCount===2){assert.equal(options.headers['X-Token'],'answer-token');assert.equal(options.headers['2FA-Token'],'answer-2fa');}
   return new Response('',{headers:{'X-GTK':'gtk-'+gtkCount}});
  }
  if(u.pathname==='/v3/login.awp'){
   loginCount++;assert.equal(options.headers['X-GTK'],'gtk-'+gtkCount);
   if(loginCount===1)return new Response(JSON.stringify({code:250,token:'older-body-token',data:{}}),{headers:{'X-Token':'question-token','2FA-Token':'question-2fa'}});
   assert.equal(options.headers['X-Token'],'answer-token');assert.equal(options.headers['2FA-Token'],'answer-2fa');assert.equal(data.cn,'fixture-cn');assert.equal(data.cv,'fixture-cv');assert.deepEqual(data.fa,[{cn:'fixture-cn',cv:'fixture-cv',uniq:false}]);
   // The fixture normally authenticates on its second login; forward a normal successful response.
   return new Response(JSON.stringify({code:200,token:'success',data:{accounts:[{id:42,typeCompte:'E',prenom:'Test',nom:'Fictif'}]}}));
  }
  assert.equal(options.headers['X-Token'],'question-token');assert.equal(options.headers['2FA-Token'],'question-2fa');
  const res=await fixture.fetchImpl(url,options);
  if(u.searchParams.get('verbe')==='post'){res.headers.set('X-Token','answer-token');res.headers.set('2FA-Token','answer-2fa');}
  return res;
 };
 const connector=new EcoleDirecteConnector({fetchImpl,now:testNow});assert.equal((await connector.login('local','fictif')).status,'challenge');assert.equal((await connector.challenge({choice:0})).status,'authenticated');assert.equal(connector.pending,null);
});
test('Une charte demandée après la question explique l’étape à terminer sur ÉcoleDirecte',async()=>{
 const connector=new EcoleDirecteConnector({fetchImpl:async()=>new Response(JSON.stringify({code:520}))});
 await assert.rejects(connector.request('login.awp',{data:{}}),e=>e.code==='ED_520'&&e.message.includes('charte'));
});

test('Le GTK renouvelé dans le corps remplace un ancien cookie, sans devenir le jeton du compte',async()=>{
 const connector=new EcoleDirecteConnector({fetchImpl:async()=>new Response(JSON.stringify({token:'new-gtk'}))});connector.cookies.set('GTK','old-gtk');connector.token='account-token';
 await connector.request('login.awp?gtk=1',{bootstrap:true});assert.equal(connector.gtk,'new-gtk');assert.equal(connector.token,'account-token');
});

test('Connexion : sérialisation officielle, caractères spéciaux et deux cookies transmis',async()=>{
 const calls=[],events=[];let step=0;
 const username='Élève + & %',password=' p+&%\\"漢字 ';
 const connector=new EcoleDirecteConnector({diagnostic:e=>events.push(e),fetchImpl:async(url,options)=>{
  calls.push(options);step++;
  if(step===1){const headers=new Headers();headers.append('Set-Cookie','GTK=gtk-private; Path=/; Secure');headers.append('Set-Cookie','second-proof=other-private; Path=/; Secure');return new Response('',{headers});}
  assert.ok(options.body.startsWith('data={'));assert.deepEqual(JSON.parse(new URLSearchParams(options.body).get('data')),{identifiant:username,motdepasse:password,isReLogin:false,uuid:'',fa:[]});
  assert.equal(options.headers.Cookie,'GTK=gtk-private; second-proof=other-private');assert.equal(options.headers['X-GTK'],'gtk-private');
  return new Response(JSON.stringify({code:505,message:password,token:'never-log-token'}));
 }});
 await assert.rejects(connector.login(username,password),e=>e.code==='ED_505'&&e.message.includes('site officiel'));
 assert.equal(calls.length,2);assert.equal(events[0].code,'READY');assert.equal(events[1].code,505);assert.equal(events[1].cookieCount,2);
 for(const secret of [username,password,'gtk-private','other-private','never-log-token'])assert.ok(!JSON.stringify(events).includes(secret));
 assert.equal(connector.cookies.size,0);assert.equal(connector.pending,null);
});

test('Diagnostic distingue blocage HTTP, préparation manquante et refus du compte',async()=>{
 for(const [response,code] of [[new Response('blocked',{status:403}),'HTTP'],[new Response(''),'GTK_MISSING']]){
  const events=[],connector=new EcoleDirecteConnector({diagnostic:e=>events.push(e),fetchImpl:async()=>response});
  await assert.rejects(connector.login('fictif','fictif'));assert.equal(events.at(-1).code,code);assert.equal(connector.pending,null);
 }
});
