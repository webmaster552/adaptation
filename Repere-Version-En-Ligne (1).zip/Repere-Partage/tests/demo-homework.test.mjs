import test from 'node:test';
import assert from 'node:assert/strict';
import {createDemoStudents} from '../dist/engine.mjs';
import {demoPlanner,studyWeek} from '../dist/study.mjs';
import {homeworkAnswer} from '../server/tutor.mjs';

test('demo conversation lists the same forthcoming test as the notebook',()=>{
  const now=new Date('2026-10-20T12:00:00'),student=createDemoStudents()[0];
  const planner=demoPlanner(student,studyWeek(now));
  const answer=homeworkAnswer('Quels sont mes devoirs et mes contrôles à venir ?',planner,now);
  assert.equal(answer.homework.length,1);
  assert.equal(answer.homework[0].date,'2026-10-23');
  assert.equal(answer.homework[0].text,planner.homework[0].text);
  assert.match(answer.body,/équations du premier degré/);
});
