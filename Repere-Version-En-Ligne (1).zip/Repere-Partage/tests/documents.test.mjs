import test from 'node:test';
import assert from 'node:assert/strict';
import {splitText,documentMaterial,planPreparations,runPreparationPack,readPhotoBatch,renderSheet} from '../dist/documents.mjs';
import {readDocumentPhoto,findPageBreak} from '../dist/photo-reading.mjs';
import {validateTutorInput,LocalTutor} from '../dist/tutor-core.mjs';
import {createDemoStudents} from '../dist/engine.mjs';

test('20 pages longues sont toutes présentes, dans l’ordre, avec des requêtes valides',()=>{
 const photos=Array.from({length:20},(_,i)=>({text:`DÉBUT-${i} `+'Cours. '.repeat(1800)+` FIN-${i}`}));
 const material=documentMaterial({id:'m',title:'Cours',photos});const batches=planPreparations([material]);assert.ok(batches.length>1);
 for(const batch of batches)validateTutorInput({kind:'sheet',materials:batch});
 const combined=batches.flat().map(m=>m.text).join('');assert.equal(combined,photos.map(p=>p.text).join(''));
 assert.ok(batches.flat().at(-1).title.includes('Page 20'));
});
test('Le découpage conserve accents, retours, caractères et limites des documents',()=>{
 const text='Équation 🌍\n\n  2x − 8 = 10. '.repeat(700);assert.equal(splitText(text).join(''),text);
 const docs=[{id:'a',title:'A',text:'x'.repeat(100)},{id:'b',title:'B',text:'y'.repeat(100)}];assert.equal(planPreparations(docs).length,1);assert.equal(planPreparations(docs,{separate:true}).length,2);
 assert.throws(()=>planPreparations([documentMaterial({photos:[{data:'image',text:''}]})]),/pas encore lues/);
});
test('Une interruption du lot garde les fiches finies et ne lance pas la suivante',async()=>{
 let cancelled=false,calls=0;const saved=[];
 const count=await runPreparationPack({batches:[[1],[2],[3]],run:async()=>({title:String(++calls)}),save:async a=>{saved.push(a);cancelled=true;},cancelled:()=>cancelled});assert.equal(count,1);assert.equal(calls,1);assert.equal(saved.length,1);
 await assert.rejects(runPreparationPack({batches:[[1],[2]],run:async()=>{if(++calls===3)throw Error('Lecture');return {};},save:async a=>saved.push(a)}));assert.equal(saved.length,2);
});
test('Le lot de photos continue après une erreur et enregistre chaque page',async()=>{
 const photos=[],snapshots=[];const report=await readPhotoBatch({files:Array.from({length:8},(_,i)=>({name:`${i}`})),photos,prepare:async f=>f.name,read:async p=>{if(p.data==='3')throw Error('Image floue');return 'Texte '+p.data;},save:async()=>snapshots.push(structuredClone(photos))});assert.deepEqual(report,{done:7,failed:1});assert.equal(photos.length,8);assert.equal(photos[3].status,'error');assert.equal(photos.at(-1).text,'Texte 7');assert.equal(snapshots.at(-1).length,8);
 await assert.rejects(readPhotoBatch({files:Array(13).fill({}),photos}),/20 photos/);
});
test('Arrêter une lecture conserve sa photo et ne lance pas le reste du lot',async()=>{
 let stop=false;const photos=[];await readPhotoBatch({files:[{name:'a'},{name:'b'}],photos,prepare:async()=>'',read:async()=>{stop=true;return 'partial';},save:async()=>{},cancelled:()=>stop});assert.equal(photos.length,1);assert.equal(photos[0].status,'pending');assert.equal(photos[0].text,'');
});
test('La lecture ordinaire reste rapide ; une incertitude déclenche deux zones',async()=>{
 let calls=[];const tutor={run:async input=>{calls.push(input.images[0]);return {body:input.images[0]==='page'?'Début [illisible]':'Texte '+input.images[0]};}};
 assert.equal(await readDocumentPhoto({data:'page',tutor,parts:async()=>['haut','bas']}),'Texte haut\n\nTexte bas');assert.deepEqual(calls,['page','haut','bas']);
 calls=[];await readDocumentPhoto({data:'clair',tutor,parts:async()=>{throw Error('Ne doit pas découper');}});assert.deepEqual(calls,['clair']);
 calls=[];await readDocumentPhoto({data:'page',tutor,detailed:true,parts:async()=>['haut','bas']});assert.deepEqual(calls,['haut','bas']);
});
test('Une relecture en échec conserve la première transcription, sans inventer la partie illisible',async()=>{
 const body='Texte [illisible]';const tutor={run:async()=>({body})};assert.equal(await readDocumentPhoto({data:'page',tutor,parts:async()=>{throw Error('Trop grand');}}),body);
 let stop=false;await assert.rejects(readDocumentPhoto({data:'page',tutor:{run:async()=>{stop=true;return {body};}},cancelled:()=>stop,parts:async()=>['a']}),/arrêtée/);
});
test('Le découpage choisit une bande blanche et évite la ligne au centre',()=>{
 const w=100,h=200,p=new Uint8ClampedArray(w*h*4).fill(255);for(let y=97;y<=105;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;p[i]=p[i+1]=p[i+2]=0;}
 const cut=findPageBreak(p,w,h);assert.ok(cut<95||cut>107);assert.ok(cut>=h*.38&&cut<=h*.62);
});
test('Les réponses restent séparées et le texte d’une fiche est échappé',()=>{
 const sheet={essentials:'<script>danger</script>',method:'M',example:'E',mistakes:'P',questions:['Q'],answers:['A']};const esc=s=>s.replaceAll('<','&lt;').replaceAll('>','&gt;');const html=renderSheet({sheet},esc);assert.ok(!html.includes('<script>'));assert.match(html,/<details><summary>Voir la réponse/);
});
test('La fiche refuse un corrigé manquant et conserve ses rubriques et ses réponses',async()=>{
 const answer={title:'Égalité',essentials:'E',method:'M',example:'X',mistakes:'P',questions:['1','2','3','4']};const tutor=new LocalTutor({fetchImpl:async()=>new Response(JSON.stringify({done_reason:'stop',message:{content:JSON.stringify(answer)}}))});const input={kind:'sheet',materials:[{title:'Cours',text:'2x = 8'}]},context={student:createDemoStudents()[0]};await assert.rejects(tutor.generate(input,context),{code:'TUTOR_INCOMPLETE'});answer.answers=['A','B','C','D'];const result=await tutor.generate(input,context);assert.deepEqual(result.sheet.answers,answer.answers);assert.match(result.correction,/4\. 4\nD/);
});

test('La version imprimable contient les rubriques et échappe les titres et les sources',async()=>{
 const {printableDocument}=await import('../dist/documents.mjs');const html=printableDocument({title:'<img onerror=bad>',sources:['<source>'],body:'Cours'});assert.ok(!html.includes('<img'));assert.ok(html.includes('&lt;source&gt;'));assert.match(html,/@media print/);
});
