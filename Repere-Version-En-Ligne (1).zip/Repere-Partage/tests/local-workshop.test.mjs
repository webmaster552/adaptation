import test from 'node:test';
import assert from 'node:assert/strict';
import {LocalTutor} from '../server/tutor.mjs';
import {createDemoStudents} from '../dist/engine.mjs';
const student=createDemoStudents()[0],materials=[{title:'Équations',text:'3x + 5 = 17. x = 4.'}];
const options={scope:'teacher',subject:'Mathématiques',materials};
const answer={title:'Questions',cards:Array.from({length:4},(_,i)=>({question:`Question ${i+1}`,hint:'Indice',answer:'Réponse réservée au corrigé'}))};
function engine(value=answer,inspect=()=>{}){return new LocalTutor({fetchImpl:async(url,request)=>{inspect(url,JSON.parse(request.body));return {ok:true,json:async()=>({message:{content:JSON.stringify(value)}})};}});}
test('Quiz : source exacte et moteur local ; support sans réponses',async()=>{
 const tutor=engine(answer,(url,body)=>{assert.equal(url,'http://127.0.0.1:11434/api/chat');assert.equal(body.model,'qwen2.5-coder:14b');assert.ok(body.messages[1].content.includes(materials[0].text));});
 const result=await tutor.generate({...options,kind:'quiz'},{});assert.equal(result.cards.length,4);assert.ok(!result.body.includes('Réponse réservée'));assert.ok(result.correction.includes('Réponse réservée'));assert.equal(tutor.active,0);
});
test('Nouveaux outils : cours obligatoire, accès professeur et dossier obligatoire',async()=>{
 const tutor=engine();await assert.rejects(()=>tutor.generate({kind:'adapt',materials},{}),{code:'TEACHER_REQUIRED'});await assert.rejects(()=>tutor.generate({scope:'teacher',kind:'meeting'},{}),{code:'FORBIDDEN_STUDENT'});await assert.rejects(()=>tutor.generate({kind:'quiz',materials:[]},{student}),{code:'COURSE_REQUIRED'});await assert.rejects(()=>tutor.generate({...options,kind:'explain'},{}),{code:'INVALID_SCOPE'});
});
test('Échange : identité et photo exclues du contexte ; faits conservés',async()=>{
 const tutor=engine({title:'Échange',questions:['Q1','Q2','Q3'],actions:['A1','A2'],closing:'À convenir'},(url,body)=>{const ctx=body.messages[1].content;assert.ok(!ctx.includes(student.firstName));assert.ok(!ctx.includes(student.lastName));assert.ok(!ctx.includes('photo-secret'));assert.ok(JSON.parse(ctx).observations.length);});
 const result=await tutor.generate({scope:'teacher',kind:'meeting'},{student:{...student,photo:'photo-secret'}});assert.ok(result.facts.length);assert.ok(result.body.includes(result.facts[0]));
});
test('Sortie incomplète refusée et verrou libéré après erreur',async()=>{
 const tutor=engine({...answer,cards:answer.cards.slice(0,2)});await assert.rejects(()=>tutor.generate({...options,kind:'quiz'},{}),{code:'TUTOR_INCOMPLETE'});assert.equal(tutor.active,0);
});
test('Annulation libère le moteur et interdit une génération concurrente',async()=>{
 const abort=new AbortController();const tutor=new LocalTutor({fetchImpl:async(url,{signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(new Error('aborted')),{once:true}))});
 const pending=tutor.generate({...options,kind:'quiz'},{signal:abort.signal});await assert.rejects(()=>tutor.generate({...options,kind:'quiz'},{}),{code:'TUTOR_BUSY'});abort.abort();await assert.rejects(()=>pending,{code:'CANCELLED'});assert.equal(tutor.active,0);
});
