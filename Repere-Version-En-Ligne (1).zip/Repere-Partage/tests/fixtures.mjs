// Fixtures entirely fictitious. Injected by tests only; production never imports this file.
export const testNow=()=>new Date('2026-10-19T10:00:00Z');
export const notes={notes:[...['2026-09-01','2026-09-08','2026-09-15'].map((date,i)=>({id:i+1,date,valeur:'14,0',noteSur:'20',coef:'1',libelleMatiere:'Mathématiques'})),...['2026-10-01','2026-10-08','2026-10-15'].map((date,i)=>({id:i+4,date,valeur:'10',noteSur:'20',coef:'1',libelleMatiere:'Mathématiques'}))]};
export const life={absencesRetards:[{id:1,typeElement:'Absence',date:'2026-10-07',libelle:'2 demi-journées',justifie:false},{id:2,typeElement:'Absence',date:'2026-10-09',libelle:'1 demi-journée',justifie:true},{id:3,typeElement:'Retard',date:'2026-10-12'}]};
const response=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json',...headers}});
export function makeFixtureFetch({teacher=false,challenge=null,denied=false,failAttendance=false,profileSchool=false,profilePhoto=false}={}){
 const calls=[];let posts=0;
 const fetchImpl=async(url,options)=>{
  const u=new URL(url),data=options.body?JSON.parse(new URLSearchParams(options.body).get('data')):null;calls.push({url:u,options,data});
  if(u.pathname==='/v3/login.awp'&&options.method==='GET')return response({},200,{'Set-Cookie':'GTK=fixture-gtk; Path=/; Secure'});
  if(u.pathname==='/v3/login.awp'){
   posts++;if(denied)return response({code:505});
   if(challenge&&posts===1)return response({code:250,token:'fixture-pending',data:{totp:challenge==='totp'}});
   return response({code:200,token:'fixture-secret-token',data:{accounts:[{id:teacher?99:42,typeCompte:teacher?'P':'E',prenom:'Compte',nom:'Fictif',nomEtablissement:profileSchool?'':'Établissement de test',profile:{nomEtablissement:profileSchool?'Collège du Profil':'',classe:{libelle:'2de Test'},...(teacher?{classes:[{id:7,libelle:'2de Test'},{id:7,libelle:'2de Test'}],groupes:[{id:8,libelle:'Groupe Test'}]}:{})}}]}});
  }
  if(u.pathname==='/v3/connexion/doubleauth.awp')return u.searchParams.get('verbe')==='get'?response({code:200,data:{question:Buffer.from('Choisissez « Oui »').toString('base64'),propositions:['Oui','Non'].map(s=>Buffer.from(s).toString('base64'))}}):response({code:200,data:{cn:'fixture-cn',cv:'fixture-cv'}});
  if(u.pathname==='/v3/classes/7/eleves.awp'||u.pathname==='/v3/groupes/8/eleves.awp')return response({code:200,data:{eleves:[{id:42,prenom:'Élève',nom:'Fictif',classe:{libelle:'2de Test'},photo:'https://malicious.example/photo.jpg'},{id:43,prenom:'Autre',nom:'Fictif',classe:{libelle:'2de Test'}}]}});
  if(/^\/v3\/eleves\/(42|43)\.awp$/.test(u.pathname))return response({code:200,data:{id:Number(u.pathname.match(/(42|43)/)[1]),prenom:'Compte',nom:'Fictif',classeLibelle:'2de Test',photo:profilePhoto?'//doc1.ecoledirecte.com/PhotoEleves/fixture.png':'',nomEtablissement:profileSchool?'Collège du Profil':'Établissement de test'}});
  if(u.hostname==='doc1.ecoledirecte.com'&&u.pathname==='/PhotoEleves/fixture.png')return new Response(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jijIAAAAASUVORK5CYII=','base64'),{headers:{'Content-Type':'image/png'}});
  const fixturePlanner=plannerResponse(u,data);if(fixturePlanner)return response({code:200,data:fixturePlanner});
  if(/^\/v3\/eleves\/(42|43)\/notes.awp$/.test(u.pathname))return response({code:200,data:notes});
  if(/^\/v3\/eleves\/(42|43)\/viescolaire.awp$/.test(u.pathname))return failAttendance?response({code:403}):response({code:200,data:life});
  throw new Error('Unexpected test request: '+u.pathname);
 };
 return {fetchImpl,calls};
}

export function makeFamilyFetch({twoAccounts=false,wrongContext=false}={}){
 const base=makeFixtureFetch({profileSchool:true,profilePhoto:true});let current=70;const requests=[];
 const child=(id)=>({id,prenom:id===42?'Nina':'Mathis',nom:'Morel',nomEtablissement:id===42?'Collège des Ormes':'Lycée Victor Hugo',classe:{libelle:id===42?'4e B':'2de A'},photo:'//doc1.ecoledirecte.com/PhotoEleves/fixture.png'});
 const account=(id,children)=>({id,idLogin:id+100,typeCompte:'F',main:id===70,prenom:'Alex',nom:'Morel',nomEtablissement:id===70?'Collège des Ormes':'Lycée Victor Hugo',profile:{eleves:children}});
 const accounts=twoAccounts?[account(70,[child(42)]),account(71,[child(43)])]:[account(70,[child(42),child(43)])];
 const fetchImpl=async(url,options)=>{
  const u=new URL(url);requests.push({path:u.pathname,context:current});
  if(u.pathname==='/v3/login.awp'&&options.method==='POST')return response({code:200,token:'family-secret',data:{accounts}});
  if(u.pathname==='/v3/renewtoken.awp'){const data=JSON.parse(new URLSearchParams(options.body).get('data'));current=data.idUser-100;return response({code:200,token:'new-family-secret',data:{id:wrongContext?999:current}});}
  const id=Number(u.pathname.match(/\/(?:eleves|Eleves|E)\/(\d+)/)?.[1]);
  if(id&&![42,43].includes(id))throw new Error('Unauthorized fixture student');
  if(twoAccounts&&id&&((id===42&&current!==70)||(id===43&&current!==71)))throw new Error('Wrong family context');
  if(/^\/v3\/eleves\/\d+\.awp$/.test(u.pathname))return response({code:200,data:child(id)});
  if(u.pathname.endsWith('/notes.awp'))return response({code:200,data:{notes:notes.notes.map(g=>({...g,valeur:id===43?'16':g.valeur})),periodes:[{periode:'1er trimestre',dateDebut:'2026-09-01',dateFin:'2026-12-20',ensembleMatieres:{moyenneGenerale:id===43?'16,45':'12,35',disciplines:[{discipline:'Mathématiques',moyenne:id===43?'16,45':'11,28'}]}}]}});
  if(u.pathname.endsWith('/viescolaire.awp'))return response({code:200,data:id===43?{absencesRetards:[]}:life});
  return base.fetchImpl(url,options);
 };
 return {fetchImpl,requests};
}

export function plannerFixture(start='2026-10-19'){
 const date=i=>new Date(Date.parse(start+'T12:00:00Z')+i*86400000).toISOString().slice(0,10);
 const encode=s=>Buffer.from(s).toString('base64');
 return {timetable:Array.from({length:5},(_,i)=>({id:100+i,matiere:i%2?'Français':'Mathématiques',start_date:date(i)+' 08:00:00',end_date:date(i)+' 09:00:00',salle:'B12',prof:'Mme Exemple'})),homework:{[date(4)]:[{idDevoir:900,matiere:'Mathématiques',interrogation:true,aFaire:true}]},detail:{matieres:[{id:900,matiere:'Mathématiques',interrogation:true,nomProf:'Mme Exemple',contenuDeSeance:{contenu:encode('<p>Équations du premier degré. 3x + 5 = 17 donc 3x = 12 et x = 4. Vérifier : 3 × 4 + 5 = 17.</p>'),documents:[]},aFaire:{idDevoir:900,contenu:encode('<p>Revoir les équations et refaire les exercices du chapitre.</p>'),documents:[]}}]}};
}
function plannerResponse(url,body){
 const p=plannerFixture(body?.dateDebut||'2026-10-19');
 if(/\/E\/(42|43)\/emploidutemps.awp$/.test(url.pathname))return p.timetable;
 if(/\/Eleves\/(42|43)\/cahierdetexte.awp$/.test(url.pathname))return p.homework;
 if(/\/Eleves\/(42|43)\/cahierdetexte\/\d{4}-\d{2}-\d{2}.awp$/.test(url.pathname))return url.pathname.includes('2026-10-19')||url.pathname.includes('2026-10-23')?p.detail:{matieres:[]};
 return null;
}
