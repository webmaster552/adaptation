import test from 'node:test';
import http from 'node:http';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {createPublicServer} from '../server/public-access.mjs';
import {createAppServer} from '../server.mjs';
import {EcoleDirecteConnector} from '../server/connector.mjs';
import {makeFixtureFetch,testNow} from './fixtures.mjs';
const origin='https://repere.example';
async function start(t){
 const server=await createPublicServer({origin,appFactory:()=>createAppServer({connectorFactory:()=>new EcoleDirecteConnector({...makeFixtureFetch(),now:testNow})})});
 server.listen(0,'127.0.0.1');await once(server,'listening');
 t.after(()=>new Promise(r=>{server.closeAllConnections();server.close(r);}));
 const base='http://127.0.0.1:'+server.address().port;
 const call=(path,{method='GET',body,cookie='',headers={}}={})=>new Promise((resolve,reject)=>{
  const req=http.request(base+path,{method,headers:{Host:new URL(origin).host,...(method==='POST'?{Origin:origin}:{}),...(cookie?{Cookie:cookie}:{}),...headers}},response=>{
   const chunks=[];response.on('data',c=>chunks.push(c));response.on('end',()=>{const resultHeaders=new Headers();for(let i=0;i<response.rawHeaders.length;i+=2)resultHeaders.append(response.rawHeaders[i],response.rawHeaders[i+1]);resolve(new Response(Buffer.concat(chunks),{status:response.statusCode,headers:resultHeaders}));});
  });req.on('error',reject);req.end(body);
 });
 return {call};
}
const post={method:'POST',headers:{'Content-Type':'application/json','X-Repere-Request':'1'}};
test('Le lien ouvre directement l’application, y compris les anciens favoris',async t=>{
 const {call}=await start(t);
 const page=await call('/');assert.equal(page.status,200);const html=await page.text();assert.ok(!html.includes('Votre espace privé'));assert.ok(!html.includes('Quitter l’espace privé'));
 assert.equal((await call('/app.js')).status,200);
 assert.equal((await(await call('/api/session')).json()).status,'disconnected');
 for(const path of ['/private/login','/private/logout']){const r=await call(path);assert.equal(r.status,303);assert.equal(r.headers.get('location'),'/');}
});
test('Les informations scolaires restent protégées sans session',async t=>{
 const {call}=await start(t);
 for(const path of ['/api/sync','/api/photo/ed-1'])assert.equal((await call(path)).status,401);
 assert.equal((await call('/api/planner',{...post,body:'{}'})).status,401);
 for(const path of ['/server.mjs','/render.yaml','/.env'])assert.equal((await call(path)).status,404);
});
test('Deux visiteurs gardent des sessions ÉcoleDirecte indépendantes',async t=>{
 const {call}=await start(t),cookies=[];
 for(let i=0;i<2;i++){
  const r=await call('/api/login',{...post,body:JSON.stringify({username:'fictif',password:'fictif'})});assert.equal(r.status,200);
  const value=r.headers.get('set-cookie');assert.match(value,/Secure/);assert.match(value,/HttpOnly/);assert.match(value,/SameSite=Strict/);cookies.push(value.split(';')[0]);
 }
 assert.notEqual(cookies[0],cookies[1]);
 for(const cookie of cookies)assert.equal((await(await call('/api/session',{cookie})).json()).status,'authenticated');
 assert.equal((await(await call('/api/session')).json()).status,'disconnected');
 await call('/api/logout',{...post,cookie:cookies[0],body:'{}'});
 assert.equal((await(await call('/api/session',{cookie:cookies[0]})).json()).status,'disconnected');
 assert.equal((await(await call('/api/session',{cookie:cookies[1]})).json()).status,'authenticated');
});
test('Le proxy public conserve les contrôles d’origine et d’hôte',async t=>{
 const {call}=await start(t);
 assert.equal((await call('/',{headers:{Host:'intrus.example','X-Forwarded-Host':'repere.example'}})).status,403);
 assert.equal((await call('/api/login',{...post,headers:{...post.headers,Origin:'https://intrus.example'},body:'{}'})).status,403);
 assert.equal((await call('/api/session',{headers:{'Sec-Fetch-Site':'cross-site'}})).status,403);
 assert.equal((await call('/',{headers:{'Sec-Fetch-Site':'cross-site'}})).status,200);
 assert.equal((await call('//intrus.example')).status,400);
 assert.equal(await(await call('/healthz')).text(),'ok');
});
