import test from 'node:test';
import assert from 'node:assert/strict';
import {createTutorClient} from '../dist/tutor-client.mjs';
import {createBrowserTutor,redactAndLimitMessages} from '../dist/browser-tutor.mjs';
import {createDemoStudents} from '../dist/engine.mjs';
import {validateTutorInput,LocalTutor} from '../dist/tutor-core.mjs';

test('IA navigateur : aucun message, document ou historique envoyé au serveur',async()=>{
 const calls=[],student=createDemoStudents()[0];let received;
 const client=createTutorClient({request:async(path,data)=>{calls.push({path,data});return path.endsWith('/status')?{mode:'browser'}:{student,planner:null};},loadBrowser:async()=>({createBrowserTutor:()=>({generate:async(input,context)=>{received={input,context};return {title:'Test',body:'Réponse'};}})})});
 const input={kind:'chat',demo:true,studentId:student.id,question:'Question privée',materials:[{text:'Cours privé'}],history:[{role:'user',content:'Conversation privée'}]};
 assert.equal((await client.run(input)).body,'Réponse');assert.deepEqual(received.input,input);assert.equal(received.context.student,student);
 assert.deepEqual(calls,[{path:'/api/tutor/status',data:undefined},{path:'/api/tutor/context',data:{demo:true,studentId:student.id}}]);
});
test('IA navigateur : un navigateur sans WebGPU reçoit une explication claire',async()=>{
 const tutor=createBrowserTutor({gpu:()=>undefined});await assert.rejects(tutor.prepare(),/WebGPU/);assert.equal(tutor.state.ready,false);
});
test('Bilan immédiat sans téléchargement du modèle, à partir des données disponibles',async()=>{
 const tutor=createBrowserTutor({loadLibrary:()=>{throw Error('Ne doit pas télécharger');}});
 const answer=await tutor.generate({kind:'analysis',materials:[]},{student:createDemoStudents()[0]});assert.ok(answer.insights.length);assert.equal(tutor.state.ready,false);
});
test('La lecture des photos fonctionne sans WebGPU et restitue une transcription',async()=>{
 let terminated=0;
 const tutor=createBrowserTutor({gpu:()=>undefined,loadOCR:async()=>({createWorker:async()=>({recognize:async()=>({data:{text:'Cours de test',confidence:95}}),terminate:async()=>{terminated++;}})})});
 const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jijIAAAAASUVORK5CYII=';
 const result=await tutor.generate({kind:'ocr',images:[image]},{});assert.equal(result.body,'Cours de test');assert.equal(terminated,1);assert.match(result.notice,/manuscrite/);
 assert.throws(()=>validateTutorInput({kind:'ocr',images:['data:image/png;base64,YWJjZA==']}),/reconnu/);
});
test('Un cours trop long est refusé explicitement plutôt que tronqué en silence',()=>{
 assert.throws(()=>redactAndLimitMessages([{content:'a'.repeat(19001)}]),/passage/);
});
test('Annulation pendant la récupération du dossier empêche toute génération',async()=>{
 let resolve,called=false;
 const client=createTutorClient({request:async path=>path.endsWith('/status')?{mode:'browser'}:new Promise(r=>{resolve=r;}),loadBrowser:async()=>({createBrowserTutor:()=>({generate:async()=>{called=true;}})})});
 const pending=client.run({kind:'chat',demo:true,studentId:'demo-1'});await new Promise(r=>setImmediate(r));await client.cancel();resolve({student:{}});await assert.rejects(pending,/annulée/);assert.equal(called,false);
});

test('Une image base64 mal formée produit une erreur de validation',()=>{
 assert.throws(()=>validateTutorInput({kind:'ocr',images:['data:image/png;base64,A']}),error=>error.code==='INVALID_IMAGE');
});

test('Un corrigé qui recopie les questions ne devient pas un contrôle terminé',async()=>{
 const tutor=new LocalTutor({browser:true,fetchImpl:async(url,opts)=>{
  const body=JSON.parse(opts.body);const answer=body.format.properties.solutions?{solutions:Array(4).fill('1. Résoudre 2x = 8.')}:{title:'Équations',exercises:Array(4).fill({title:'Équation',question:'Résoudre 2x = 8.',solution:'x = 4'})};
  return new Response(JSON.stringify({done_reason:'stop',message:{content:JSON.stringify(answer)}}));
 }});
 await assert.rejects(tutor.generate({kind:'practice',materials:[{title:'Cours',text:'Résoudre une équation'}]},{student:createDemoStudents()[0]}),{code:'TUTOR_REVIEW_FAILED'});
 assert.equal(tutor.active,0);
});


test('Les ateliers élèves et professeurs génèrent dans le navigateur',async()=>{
 const calls=[];
 const tutor=createBrowserTutor({gpu:()=>({requestAdapter:async()=>({features:new Set(['shader-f16'])})}),workerFactory:()=>({addEventListener(){},terminate(){}}),loadLibrary:async()=>({CreateWebWorkerMLCEngine:async()=>({chat:{completions:{create:async function*(request){
  calls.push(request);const schema=JSON.parse(request.response_format.schema);
  const value=schema.properties.cards?{title:'Quiz',cards:Array.from({length:4},(_,i)=>({question:`Question ${i+1}`,hint:'Indice',answer:'Réponse expliquée'}))}:{title:'Trois activités',essentials:'Le cours',guided:{instruction:'A',hint:'B',answer:'C'},independent:{instruction:'D',hint:'E',answer:'F'},extension:{instruction:'G',hint:'H',answer:'I'}};
  yield {choices:[{delta:{content:JSON.stringify(value)},finish_reason:'stop'}]};
 }}}})})});
 const materials=[{title:'Cours',text:'Une équation conserve son égalité en effectuant la même opération des deux côtés.'}];
 const quiz=await tutor.generate({kind:'quiz',materials},{student:createDemoStudents()[0]});
 assert.equal(quiz.cards.length,4);assert.match(quiz.model,/sur cet appareil/);
 const adapted=await tutor.generate({kind:'adapt',scope:'teacher',materials},{});
 assert.match(adapted.body,/En autonomie/);assert.equal(calls.length,2);
 await assert.rejects(tutor.generate({kind:'adapt',materials},{}),{code:'TEACHER_REQUIRED'});
});


test('La préparation d’un échange demande explicitement le dossier professeur autorisé',async()=>{
 let received;const student=createDemoStudents()[0];
 const client=createTutorClient({request:async(path,input)=>{if(path.endsWith('/status'))return {mode:'browser'};received=input;return input.kind==='meeting'?{student}:{};},loadBrowser:async()=>({createBrowserTutor:()=>({generate:async(input,context)=>{assert.equal(context.student.id,student.id);return {body:'Échange'};}})})});
 await client.run({kind:'meeting',scope:'teacher',demo:true,studentId:student.id});
 assert.deepEqual(received,{studentId:student.id,demo:true,scope:'teacher',kind:'meeting'});
});
