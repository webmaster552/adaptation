const text=(v,n=6000)=>typeof v==='string'?v.slice(0,n):'';
const yes=v=>v===true||v===1||v==='1';
export function schoolText(value){
 if(typeof value!=='string')return '';
 let html=value;try{if(!value.includes('<')&&/^[A-Za-z0-9+/=\s]+$/.test(value))html=Buffer.from(value,'base64').toString('utf8');}catch{}
 return html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,'').replace(/<\/(?:p|div|li|h\d)>|<br\s*\/?>/gi,'\n').replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&amp;/g,'&').replace(/&#(\d+);/g,(_,n)=>Number(n)<=0x10ffff?String.fromCodePoint(Number(n)):'').trim().slice(0,12000);
}
export function normalizeTimetable(data){
 if(!Array.isArray(data))throw new Error('Format emploi du temps inconnu');
 return data.filter(e=>e&&typeof e.start_date==='string'&&typeof e.end_date==='string').map((e,i)=>({id:String(e.id??i),subject:text(e.matiere||e.text,150),code:text(e.codeMatiere,40),start:text(e.start_date,30),end:text(e.end_date,30),teacher:text(e.prof,150),room:text(e.salle,80),cancelled:yes(e.isAnnule),modified:yes(e.isModifie),hasHomework:yes(e.devoirAFaire),hasContent:yes(e.contenuDeSeance)})).sort((a,b)=>a.start.localeCompare(b.start));
}
const documents=items=>(Array.isArray(items)?items:[]).map(d=>({name:text(d.libelle||d.nom||d.displayText||d.name,200)||'Document du cours',type:text(d.type||d.extension,50)}));
export function normalizeHomework(data){
 if(!data||typeof data!=='object'||Array.isArray(data))throw new Error('Cahier de textes inconnu');
 return Object.entries(data).filter(([date,items])=>/^\d{4}-\d{2}-\d{2}$/.test(date)&&Array.isArray(items)).flatMap(([date,items])=>items.map((e,i)=>({id:String(e.idDevoir??`${date}-${i}`),date,subject:text(e.matiere,150),code:text(e.codeMatiere,40),test:yes(e.interrogation),done:yes(e.effectue),assignedOn:text(e.donneLe,10),text:'',documents:[]}))).sort((a,b)=>a.date.localeCompare(b.date));
}
export function normalizeDay(data,date){
 if(!Array.isArray(data?.matieres))throw new Error('Détail du cahier de textes inconnu');
 return data.matieres.map((e,i)=>({id:String(e.id??`${date}-${i}`),date,subject:text(e.matiere,150),code:text(e.codeMatiere,40),teacher:text(e.nomProf,150),test:yes(e.interrogation),homework:e.aFaire&&typeof e.aFaire==='object'?{id:String(e.aFaire.idDevoir??e.id??i),text:schoolText(e.aFaire.contenu),done:yes(e.aFaire.effectue),documents:documents(e.aFaire.documents)}:null,lesson:schoolText(e.contenuDeSeance?.contenu),documents:documents(e.contenuDeSeance?.documents)}));
}
export function weekDates(start){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(start)||!Number.isFinite(Date.parse(start+'T12:00:00Z'))||new Date(start+'T12:00:00Z').toISOString().slice(0,10)!==start)throw new Error('Date invalide');
 return Array.from({length:7},(_,i)=>new Date(Date.parse(start+'T12:00:00Z')+i*86400000).toISOString().slice(0,10));
}
