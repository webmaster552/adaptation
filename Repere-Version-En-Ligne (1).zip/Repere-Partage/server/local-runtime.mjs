import {ConnectorError} from './connector.mjs';

// Preserve every selected document. Reserve room for the answer instead of letting
// Ollama silently truncate the beginning of a long course or conversation.
export function localContextSize(payload){
 const chars=payload.messages.reduce((n,m)=>n+String(m.content||'').length,0);
 const reserve=(payload.options?.num_predict||2400)+1024;
 const estimate=Math.ceil(chars/2)+reserve;
 if(estimate>16384)throw new ConnectorError('MATERIAL_LIMIT','Ce dossier est trop long. Sélectionnez moins de documents pour garder une lecture complète.',413);
 return estimate>8192?16384:8192;
}

export function localRuntimeFetch(fetchImpl=fetch,onProgress=()=>{}){
 return async(url,options)=>{
  if(url!=='http://127.0.0.1:11434/api/chat')return fetchImpl(url,options);
  const payload=JSON.parse(options.body);
  payload.keep_alive='10m';
  payload.options={...payload.options,num_ctx:localContextSize(payload)};
  payload.stream=true;
  const review=!!payload.format?.properties?.solutions;
  const started=performance.now();
  onProgress({message:review?'Vérification du corrigé…':'Lecture de votre demande…',phase:review?'review':'reading'});
  const response=await fetchImpl(url,{...options,body:JSON.stringify(payload)});
  if(!response.ok||!response.headers?.get('content-type')?.includes('ndjson'))return response;
  const reader=response.body.getReader(),decoder=new TextDecoder();
  let pending='',content='',final=null,firstTokenMs=null,lastUpdate=-Infinity;
  function consume(line){
   if(!line.trim())return;
   const part=JSON.parse(line);
   if(part.error)throw new Error('Local model error');
   const text=part.message?.content||'';
   if(text){
    firstTokenMs??=performance.now()-started;
    content+=text;
    if(content.length>180000)throw new Error('Local response too large');
    if(performance.now()-lastUpdate>350){
     onProgress({message:review?'Vérification du corrigé en cours…':'Rédaction en cours…',phase:review?'review':'writing',characters:content.length});
     lastUpdate=performance.now();
    }
   }
   if(part.done)final=part;
  }
  try{
   for(;;){
    options.signal?.throwIfAborted();
    const {value,done}=await reader.read();
    if(done)break;
    pending+=decoder.decode(value,{stream:true});
    if(pending.length>200000)throw new Error('Invalid local stream');
    let newline;while((newline=pending.indexOf('\n'))>=0){consume(pending.slice(0,newline));pending=pending.slice(newline+1);}
   }
   pending+=decoder.decode();consume(pending);
   if(!final)throw new Error('Incomplete local stream');
   onProgress({message:'Vérification du résultat…',phase:'checking'});
   return new Response(JSON.stringify({...final,message:{role:'assistant',content},first_token_ms:firstTokenMs}),{headers:{'Content-Type':'application/json'}});
  }finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
 };
}
