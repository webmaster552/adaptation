// Shared tutoring logic: the Mac uses Ollama; the public site runs it in the browser.
export * from '../dist/tutor-core.mjs';
import {LocalTutor as BaseTutor} from '../dist/tutor-core.mjs';
import {WORKSHOP_KINDS,generateWorkshop} from './local-workshop.mjs';
import {validateTutorInput} from '../dist/tutor-core.mjs';
import {ConnectorError} from './connector.mjs';
import {localRuntimeFetch} from './local-runtime.mjs';
import {createHash} from 'node:crypto';
export class LocalTutor extends BaseTutor{
 constructor({fetchImpl=fetch,model='qwen3.5:4b',reviewModel='qwen2.5-coder:14b',...options}={}){
  // Use the fast multimodal engine for reading and common student tasks.
  // Keep the original larger model for teacher supports and language exercises.
  let progress=()=>{};
  super({...options,model,chatModel:model,fetchImpl:localRuntimeFetch(fetchImpl,p=>progress(p))});
  this.setProgress=fn=>{progress=fn||(()=>{});};
  this.reviewModel=reviewModel;
  this.readings=new Map();
  this.running=false;
  this.selectModel=input=>input.kind==='ocr'?'qwen3.5:4b':(['lesson','adapt','quiz','explain','meeting'].includes(input.kind)||/fran[cç]ais|histoire|philosophie/i.test(input.subject||''))?this.reviewModel:this.model;
 }
 cleanup(){for(const [key,value]of this.readings)if(value.expires<Date.now())this.readings.delete(key);}
 clear(){this.readings.clear();}
 async generate(input,context={}){
  if(this.running)throw new ConnectorError('TUTOR_BUSY','Une préparation est déjà en cours.',409);
  context.signal?.throwIfAborted();
  this.running=true;this.setProgress(context.onProgress);
  try{
   let imageKey;
   if(input.kind==='ocr'){
    const clean=validateTutorInput(input);
    imageKey=createHash('sha256').update(clean.images[0]).digest('hex');
    this.cleanup();
    if(this.readings.has(imageKey))return {...this.readings.get(imageKey).answer,cached:true};
    context.onProgress?.({phase:'reading',message:'Lecture de la photo…'});
   }
   const result=await(WORKSHOP_KINDS.includes(input.kind)?generateWorkshop(this,input,context):super.generate(input,context));
   context.signal?.throwIfAborted();
   if(imageKey){
    // Only identical image bytes reuse a transcription. Generated replies are never cached.
    if(this.readings.size>=16)this.readings.delete(this.readings.keys().next().value);
    this.readings.set(imageKey,{answer:result,expires:Date.now()+600000});
   }
   return result;
  }finally{this.running=false;this.setProgress();}
 }
}
