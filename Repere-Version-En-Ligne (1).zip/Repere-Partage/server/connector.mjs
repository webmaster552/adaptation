import {createHash} from 'node:crypto';
import {normalizeTimetable,normalizeHomework,normalizeDay,weekDates} from './planner.mjs';
import {identityOf,establishmentName,photoAddress} from './identity.mjs';
import {normalizedStudent,windows} from './normalize.mjs';
import {ConnectorError} from '../dist/errors.mjs';
export {ConnectorError} from '../dist/errors.mjs';
export const API_VERSION='4.103.2';
const HOSTS={login:'https://api.ecoledirecte.com',teacher:'https://apip.ecoledirecte.com'};
const ERROR_MESSAGES={505:'ÉcoleDirecte a refusé la connexion (code 505). Ce refus ne permet pas de confirmer que le mot de passe est incorrect. Si ces identifiants fonctionnent sur le site officiel, la connexion depuis Repère doit être vérifiée.',516:'Le compte est bloqué par ÉcoleDirecte. Aucune nouvelle tentative automatique.',517:'Le service ÉcoleDirecte est temporairement indisponible.',520:'ÉcoleDirecte demande l’acceptation de sa charte. Ouvrez son site officiel, terminez cette étape vous-même, puis revenez vous connecter ici.',521:'La session ÉcoleDirecte a expiré. Reconnectez-vous.',525:'La session ÉcoleDirecte a expiré. Reconnectez-vous.',535:'L’établissement ou le compte est indisponible sur ÉcoleDirecte.'};
// Same form serialization as the official web client (checked 2026-10-20).
export const encodeSchoolData=data=>'data='+JSON.stringify(data,(_key,value)=>typeof value==='string'?value.replaceAll('%','%25').replaceAll('&','%26').replaceAll('+','%2B'):value);
const safeId=v=>Number.isSafeInteger(Number(v))&&Number(v)>0?Number(v):null;
const decode=s=>{try{return Buffer.from(String(s),'base64').toString('utf8').slice(0,1000);}catch{return '';}};
export class EcoleDirecteConnector{
 constructor({fetchImpl=fetch,now=()=>new Date(),diagnostic=()=>{}}={}){this.fetch=fetchImpl;this.now=now;this.diagnostic=diagnostic;this.clear();}
 clear(){this.generation=(this.generation||0)+1;this.abort?.abort();this.abort=new AbortController();this.cookies=new Map();this.gtk='';this.token='';this.twoFactor='';this.pending=null;this.account=null;this.question=null;this.photos=new Map();this.authAttempts=0;this.identity=null;this.familyAccounts=[];this.contextId=null;this.children=new Map();this.authorizedStudents=new Map();this.planners=new Map();}
 async request(path,{data,teacher=false,bootstrap=false}={}){
  const generation=this.generation;
  const active=()=>{if(generation!==this.generation)throw new ConnectorError('SESSION_CLOSED','La session a été fermée.',401);};
  const report=(httpStatus,code)=>{if(!path.startsWith('login.awp')&&!path.startsWith('connexion/doubleauth.awp'))return;try{this.diagnostic({phase:bootstrap?'bootstrap':path.startsWith('login.awp')?'login':'challenge',version:API_VERSION,httpStatus,code,gtkPresent:!!this.gtk,cookieCount:this.cookies.size});}catch{}};
  const host=teacher?HOSTS.teacher:HOSTS.login;
  const url=`${host}/v3/${path}${path.includes('?')?'&':'?'}v=${API_VERSION}`;
  const headers={'Accept':'application/json','User-Agent':'Repere/0.2 (local school dashboard test)'};
  if(this.cookies.size)headers.Cookie=[...this.cookies].map(([k,v])=>`${k}=${v}`).join('; ');
  if(this.token)headers['X-Token']=this.token;
  if(this.twoFactor)headers['2FA-Token']=this.twoFactor;
  if(path.startsWith('login.awp')&&!bootstrap&&this.gtk)headers['X-GTK']=this.gtk;
  if(data!==undefined)headers['Content-Type']='application/x-www-form-urlencoded';
  let res;
  try{res=await this.fetch(url,{method:data===undefined?'GET':'POST',headers,body:data===undefined?undefined:encodeSchoolData(data),redirect:'manual',signal:AbortSignal.any([this.abort.signal,AbortSignal.timeout(15000)])});}
  catch{active();report(0,'NETWORK');throw new ConnectorError('UPSTREAM_UNREACHABLE','ÉcoleDirecte ne répond pas. Vérifiez la connexion puis réessayez.');}
  active();
  if(!res.ok){report(res.status,'HTTP');await res.body?.cancel();throw new ConnectorError('UPSTREAM_HTTP',`ÉcoleDirecte refuse ou ne peut pas traiter cette requête (HTTP ${res.status}). Aucun contournement n’est effectué.`);}
  let freshGtk='';
  for(const line of res.headers.getSetCookie?.()||[]){const pair=line.split(';')[0];const eq=pair.indexOf('=');if(eq>0){const key=pair.slice(0,eq),value=pair.slice(eq+1);this.cookies.set(key,value);if(key==='GTK')freshGtk=value;}}
  const headerToken=res.headers.get('x-token');
  if(headerToken)this.token=headerToken;
  if(res.headers.get('2fa-token'))this.twoFactor=res.headers.get('2fa-token');
  if(res.headers.get('x-gtk'))this.gtk=res.headers.get('x-gtk');
  let text;try{text=await res.text();}catch{active();throw new ConnectorError('UPSTREAM_INCOMPLETE','La réponse ÉcoleDirecte n’est pas arrivée entièrement. Réessayez le chargement.');}active();
  if(text.length>8_000_000)throw new ConnectorError('RESPONSE_TOO_LARGE','La réponse dépasse la taille prise en charge par cet essai.');
  if(bootstrap){
   // GTK can be returned in a cookie, header or JSON body; never reuse a stale one.
   this.gtk=this.gtk||freshGtk;
   if(!this.gtk){try{const payload=JSON.parse(text);if(typeof payload.token==='string')this.gtk=payload.token;}catch{}}
   report(res.status,this.gtk?'READY':'GTK_MISSING');
   if(!this.gtk)throw new ConnectorError('GTK_MISSING','ÉcoleDirecte n’a pas fourni le jeton de connexion attendu.');
   return {code:200};
  }
  let body;try{body=JSON.parse(text);}catch{report(res.status,'NON_JSON');throw new ConnectorError('UNSUPPORTED_RESPONSE','Réponse ÉcoleDirecte non reconnue. Le service peut imposer une vérification via son site officiel.');}
  if(!headerToken&&typeof body.token==='string'&&body.token)this.token=body.token;
  report(res.status,Number.isInteger(body.code)?body.code:'UNKNOWN');
  if(body.code!==200&&body.code!==250)throw new ConnectorError(`ED_${body.code}`,ERROR_MESSAGES[body.code]||`Données refusées ou indisponibles sur ÉcoleDirecte (code ${Number(body.code)||'inconnu'}).`,[505,520,521,525].includes(body.code)?401:502);
  return body;
 }
 async login(username,password){
  this.clear();this.pending={identifiant:username,motdepasse:password,isReLogin:false,uuid:'',fa:[]};
  try{return await this.finish(await this.loginRequest());}catch(e){this.clear();throw e;}
 }
 async loginRequest(){this.gtk='';await this.request('login.awp?gtk=1',{bootstrap:true});return this.request('login.awp',{data:this.pending});}
 publicChallenge(){
  if(!this.pending||!this.question)return null;
  return this.question.type==='totp'?{status:'challenge',type:'totp',round:this.authAttempts}:{status:'challenge',type:'question',question:this.question.question,choices:this.question.choices.map(decode),round:this.authAttempts};
 }
 async finish(body){
  if(body.code===250){
   if(++this.authAttempts>3){this.clear();throw new ConnectorError('CHALLENGE_LIMIT','ÉcoleDirecte demande trop de vérifications successives. Reconnectez-vous sur son site officiel.',401);}
   if(body.data?.totp===true){this.question={type:'totp'};return this.publicChallenge();}
   const q=await this.request('connexion/doubleauth.awp?verbe=get',{data:{}});
   if(q.code!==200||!Array.isArray(q.data?.propositions)||!q.data.question)throw new ConnectorError('CHALLENGE_UNSUPPORTED','Cette vérification nécessite le site officiel ÉcoleDirecte.');
   this.question={type:'question',question:decode(q.data.question),choices:q.data.propositions.filter(p=>typeof p==='string')};
   if(!this.question.choices.length)throw new ConnectorError('CHALLENGE_UNSUPPORTED','ÉcoleDirecte n’a proposé aucune réponse à la question. Utilisez son site officiel.');
   return this.publicChallenge();
  }
  const accounts=Array.isArray(body.data?.accounts)?body.data.accounts:[];
  this.account=accounts.find(a=>a.id===body.data?.id)||accounts.find(a=>a.current===true)||accounts.find(a=>a.main===true)||accounts[0];
  if(!this.token||!this.account||safeId(this.account.id)===null)throw new ConnectorError('ACCOUNT_UNSUPPORTED','Aucun profil exploitable n’a été retourné par ÉcoleDirecte.');
  if(!['E','P','F'].includes(this.account.typeCompte)){this.clear();throw new ConnectorError('ROLE_UNSUPPORTED','Connectez-vous avec un compte élève, parent ou professeur.',400);}
  this.familyAccounts=this.account.typeCompte==='F'?accounts.filter(a=>a.typeCompte==='F'&&safeId(a.id)!==null):[];
  this.contextId=this.account.id;this.children=new Map();
  for(const family of this.familyAccounts)for(const child of Array.isArray(family.profile?.eleves)?family.profile.eleves:[]){
   if(safeId(child?.id)===null)continue;
   const key=`ed-${family.id}-${child.id}`;this.children.set(key,{raw:identityOf(child),family});
  }
  this.identity=identityOf(this.account);this.pending=null;this.question=null;return {status:'authenticated',account:this.publicAccount()};
 }
 async challenge({code,choice}){
  if(!this.pending||!this.question)throw new ConnectorError('NO_CHALLENGE','Aucune vérification en cours.',400);
  try{
   if(this.question.type==='totp'){
    if(typeof code!=='string'||!/^\d{6}$/.test(code))throw new ConnectorError('INVALID_CODE','Saisissez les six chiffres du code.',400);
    this.pending.fa=[{cn:'',cv:code}];
   }else{
    if(!Number.isInteger(choice)||!this.question.choices[choice])throw new ConnectorError('INVALID_CHOICE','Sélectionnez une réponse.',400);
    const result=await this.request('connexion/doubleauth.awp?verbe=post',{data:{choix:this.question.choices[choice]}});
    if(result.code!==200||!result.data?.cn||!result.data?.cv)throw new ConnectorError('CHALLENGE_REJECTED','Vérification refusée par ÉcoleDirecte. Reconnectez-vous.',401);
    const {cn,cv}=result.data;this.pending={...this.pending,cn,cv,fa:[...this.pending.fa.filter(f=>f.cn!==cn),{cn,cv,uniq:false}].slice(-10)};
   }
   return await this.finish(await this.loginRequest());
  }catch(e){if(e.status!==400)this.clear();throw e;}
 }
 publicAccount(){
  if(!this.account)return null;
  const info=this.identity||identityOf(this.account),school=establishmentName(info,this.account),studentId=`ed-${this.account.id}`;
  const children=[...(this.children||[])].map(([id,{raw,family}])=>({id,firstName:raw.prenom,lastName:raw.nom,className:raw.classe?.libelle||raw.classeLibelle||'',establishment:establishmentName(raw,family),...(this.photos.has(id)?{photoUrl:`/api/photo/${id}`}:{})}));
  return {workspaceKey:createHash('sha256').update(JSON.stringify([this.account.typeCompte,this.account.id,this.account.nom,this.account.prenom])).digest('hex').slice(0,24),name:[info.prenom,info.nom].filter(Boolean).join(' ').slice(0,200),firstName:info.prenom,lastName:info.nom,role:this.account.typeCompte==='P'?'teacher':this.account.typeCompte==='F'?'parent':'student',establishment:school||'Établissement non communiqué',establishmentKnown:!!school,schoolYear:typeof this.account.anneeScolaireCourante==='string'?this.account.anneeScolaireCourante.slice(0,20):null,...(this.account.typeCompte==='F'?{children,studentId:children[0]?.id||null}:{}),...(this.account.typeCompte==='E'?{studentId,className:info.classe?.libelle||info.classeLibelle||'Classe non communiquée',...(this.photos.has(studentId)?{photoUrl:`/api/photo/${studentId}`}:{})}:{})};
 }
 async selectFamily(family){
  if(this.contextId===family.id)return;
  if(!this.familyAccounts.includes(family)||safeId(family.idLogin)===null)throw new ConnectorError('FAMILY_CONTEXT','L’accès à cet établissement n’a pas été transmis par ÉcoleDirecte.',400);
  const response=await this.request('renewtoken.awp?verbe=post',{data:{idUser:family.idLogin,uuid:''}});
  if(response.code!==200||(response.data?.id!==undefined&&safeId(response.data.id)!==safeId(family.id))){this.clear();throw new ConnectorError('FAMILY_CONTEXT','ÉcoleDirecte n’a pas confirmé l’accès à cet établissement. Reconnectez-vous.',401);}
  this.contextId=family.id;
 }
 async enrichIdentity(raw,teacher){
  const base=identityOf(raw);
  if(photoAddress(base.photo)&&(base.classe?.libelle||base.classeLibelle)&&establishmentName(base,this.account))return base;
  try{
   const detail=await this.read(`eleves/${safeId(raw.id)}.awp`,teacher);
   if(safeId(detail?.id)!==safeId(raw.id))return base;
   const extra=identityOf(detail);
   return {...base,prenom:extra.prenom||base.prenom,nom:extra.nom||base.nom,photo:extra.photo||base.photo,classe:extra.classe||base.classe,classeLibelle:extra.classeLibelle||base.classeLibelle,nomEtablissement:extra.nomEtablissement||base.nomEtablissement};
  }catch(e){if(e.status===401)throw e;return base;}
 }
 async read(path,teacher){const response=await this.request(path+'?verbe=get',{data:{anneeScolaire:''},teacher});if(response.code!==200)throw new ConnectorError('SESSION_REQUIRES_AUTH','ÉcoleDirecte demande une nouvelle connexion.',401);return response.data;}
 async sync(onProgress=()=>{}){
  if(!this.account)throw new ConnectorError('NOT_CONNECTED','Connectez-vous d’abord.',401);
  const teacher=this.account.typeCompte==='P',periods=windows(this.now()),warnings=[],roster=new Map();this.photos.clear();this.authorizedStudents.clear();this.planners.clear();
  onProgress({phase:teacher?'classes':'profile',completed:0,total:teacher?null:1});
  if(teacher){
   const profile=this.account.profile||{};
   const scopes=[...(Array.isArray(profile.classes)?profile.classes:[]).map(c=>({...c,kind:'classes'})),...(Array.isArray(profile.groupes)?profile.groupes:[]).map(c=>({...c,kind:'groupes'}))];
   const distinct=new Map(scopes.filter(c=>safeId(c.id)!==null).map(c=>[`${c.kind}-${c.id}`,c]));
   if(!distinct.size)warnings.push('ÉcoleDirecte n’a renvoyé aucune classe ou groupe autorisé pour ce professeur.');
   for(const c of distinct.values()){
    let payload;try{payload=await this.read(`${c.kind}/${safeId(c.id)}/eleves.awp`,true);}catch(e){if(e.status===401)throw e;warnings.push(`Une classe ou un groupe n’a pas pu être chargé (${e.code||'erreur'}).`);continue;}
    const entries=Array.isArray(payload)?payload:payload?.eleves;
    if(!Array.isArray(entries)){warnings.push('Le format d’une liste d’élèves n’a pas été reconnu.');continue;}
    for(const e of entries){if(safeId(e.id)===null)continue;roster.set(safeId(e.id),{...e,classLabel:e.classe?.libelle||e.classeLibelle||c.libelle||c.code});}
   }
  }else if(this.account.typeCompte==='F'){
   for(const [key,entry] of this.children)roster.set(key,{...entry.raw,family:entry.family});
   if(!roster.size)warnings.push('Aucun enfant n’a été transmis pour ce compte parent.');
  }else{
   const a=this.account;roster.set(safeId(a.id),identityOf(a));
  }
  if(roster.size>500)throw new ConnectorError('ROSTER_LIMIT','Cet essai local est limité à 500 élèves par synchronisation.',400);
  const students=[];
  for(const [key,entry] of roster){
   const id=safeId(entry.id);
   if(entry.family)await this.selectFamily(entry.family);
   onProgress({phase:'profile',completed:students.length,total:roster.size});
   const raw=await this.enrichIdentity(entry,teacher);if(this.account.typeCompte==='E')this.identity=raw;
   let notes=null,schoolLife=null;const problems=[];
   onProgress({phase:'grades',completed:students.length,total:roster.size});
   try{notes=await this.read(`eleves/${id}/notes.awp`,teacher);}catch(e){if(e.status===401)throw e;problems.push(`Notes non chargées (${e.code||'erreur'}).`);}
   onProgress({phase:'attendance',completed:students.length,total:roster.size});
   try{schoolLife=await this.read(`eleves/${id}/viescolaire.awp`,teacher);}catch(e){if(e.status===401)throw e;problems.push(`Assiduité non chargée (${e.code||'erreur'}).`);}
   const student=normalizedStudent(raw,notes,schoolLife,periods);student.warnings.push(...problems);
   if(entry.family){student.id=key;this.children.get(key).raw=raw;}
   const photo=photoAddress(raw.photo);
   if(photo){this.photos.set(student.id,photo);student.photoUrl=`/api/photo/${encodeURIComponent(student.id)}`;}
   student.establishment=establishmentName(raw,entry.family||this.account)||'Établissement non communiqué';
   this.authorizedStudents.set(student.id,{id,teacher,family:entry.family});students.push(student);
   onProgress({phase:'student',completed:students.length,total:roster.size});
  }
  return {account:this.publicAccount(),students,periods,warnings,syncedAt:this.now().toISOString(),source:'ecoledirecte'};
 }
 async planner(studentId,start,{force=false}={}){
  const entry=this.authorizedStudents.get(studentId);if(!entry)throw new ConnectorError('FORBIDDEN_STUDENT','Ce dossier n’est pas accessible depuis votre compte.',403);
  let dates;try{dates=weekDates(start);}catch{throw new ConnectorError('INVALID_DATE','Choisissez une semaine valide.',400);}
  if(Math.abs(Date.parse(start)-this.now().getTime())>370*86400000)throw new ConnectorError('INVALID_DATE','Choisissez une semaine de cette année scolaire.',400);
  const cacheKey=studentId+':'+start,cached=this.planners.get(cacheKey);if(!force&&cached&&Date.now()-cached.loadedAt<300000)return cached;
  if(entry.family)await this.selectFamily(entry.family);
  const warnings=[],availability={timetable:false,homework:false,details:false};let timetable=[],homework=[],lessons=[];
  const attempt=async(label,fn)=>{try{return await fn();}catch(e){if(e.status===401)throw e;warnings.push(label+' : non transmis ou non accessible avec ce compte.');return null;}};
  const tt=await attempt('Emploi du temps',async()=>normalizeTimetable((await this.request(`E/${entry.id}/emploidutemps.awp?verbe=get`,{teacher:entry.teacher,data:{dateDebut:dates[0],dateFin:dates[6],avecTrous:false}})).data));
  if(tt){timetable=tt;availability.timetable=true;}
  const hw=await attempt('Devoirs',async()=>normalizeHomework(await this.read(`Eleves/${entry.id}/cahierdetexte.awp`,entry.teacher)));
  if(hw){homework=hw;availability.homework=true;}
  // A week's lessons, plus nearby homework dates. Keep requests bounded and sequential:
  // family token rotation must never race another child or sync operation.
  const upcoming=homework.filter(h=>h.date>=dates[0]&&h.date<=new Date(Date.parse(dates[0])+20*86400000).toISOString().slice(0,10)).map(h=>h.date);
  const detailDates=[...new Set([...dates,...upcoming])].slice(0,21);let detailsLoaded=0;const loadedDates=[];
  for(const date of detailDates){
   const items=await attempt('Contenu du '+date,async()=>normalizeDay(await this.read(`Eleves/${entry.id}/cahierdetexte/${date}.awp`,entry.teacher),date));
   if(!items)continue;detailsLoaded++;loadedDates.push(date);lessons.push(...items);
   for(const lesson of items)if(lesson.homework){const existing=homework.find(h=>h.date===date&&(h.id===lesson.homework.id||h.subject===lesson.subject));const row={id:lesson.homework.id,date,subject:lesson.subject,code:lesson.code,test:lesson.test,...lesson.homework};if(existing)Object.assign(existing,row);else homework.push(row);}
  }
  availability.details=detailsLoaded===detailDates.length;
  homework.sort((a,b)=>a.date.localeCompare(b.date));
  const result={studentId,start,end:dates[6],timetable,homework,lessons,loadedDates,availability,warnings,loadedAt:Date.now()};
  this.planners.set(cacheKey,result);if(this.planners.size>20)this.planners.delete(this.planners.keys().next().value);return result;
 }
 async photo(studentId){
  const url=this.photos.get(studentId);if(!url)throw new ConnectorError('NO_PHOTO','Photo indisponible.',404);
  // Only URLs returned for an authorized student. Never relay authentication to a photo host.
  let r;try{r=await this.fetch(url,{redirect:'manual',signal:AbortSignal.timeout(10000),headers:{Accept:'image/png,image/jpeg,image/webp'}});}catch{throw new ConnectorError('PHOTO_UNAVAILABLE','Photo indisponible.',404);}
  const type=r.headers.get('content-type')?.split(';')[0];
  if(!r.ok||!['image/png','image/jpeg','image/webp'].includes(type)){await r.body?.cancel();throw new ConnectorError('PHOTO_UNAVAILABLE','Photo indisponible.',404);}
  const bytes=Buffer.from(await r.arrayBuffer());if(bytes.length>2_000_000)throw new ConnectorError('PHOTO_TOO_LARGE','Photo trop volumineuse.',413);return {bytes,type};
 }
}
