import http from 'node:http';
import {once} from 'node:events';
import {randomBytes,scrypt as scryptCallback,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {createAppServer} from '../server.mjs';
const scrypt=promisify(scryptCallback),TTL=8*60*60*1000;
const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cookieValue=(header,name)=>(header||'').split(';').map(v=>v.trim()).find(v=>v.startsWith(name+'='))?.slice(name.length+1);

export function configuredUsers(env=process.env){
 const users=[1,2].map(i=>({name:env[`REPERE_USER_${i}`]?.trim(),password:env[`REPERE_PASSWORD_${i}`]}));
 if(users.some(u=>!u.name||!u.password||u.name.length>80||u.password.length<16||u.password.length>512)||users[0].name===users[1].name||users[0].password===users[1].password)throw new Error('Configurez deux identifiants distincts et deux mots de passe différents d’au moins 16 caractères dans les variables Render REPERE_USER_1, REPERE_PASSWORD_1, REPERE_USER_2 et REPERE_PASSWORD_2.');
 return users;
}
const css=`:root{font:15px -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#233e36;background:#f4f6f1}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px}.card{width:min(100%,410px);background:white;border:1px solid #dfe6d9;border-radius:14px;padding:36px}.brand{font-size:30px;letter-spacing:-1px;font-weight:700;margin-bottom:34px}h1{font-size:23px;letter-spacing:-.4px}p{color:#66776c;line-height:1.65;font-size:14px}label{display:block;margin:20px 0 8px;font-size:13px}input{width:100%;padding:13px;border:1px solid #cbd7c9;border-radius:6px;font:inherit}input:focus{outline:2px solid #8aa78b;outline-offset:2px}button{width:100%;margin-top:24px;padding:13px;border:0;background:#244d43;color:white;font:inherit;font-weight:600;border-radius:6px;cursor:pointer}.error{padding:12px;background:#fbf1e8;color:#8b442b;border-radius:6px}.foot{font-size:12px;margin-top:22px}`;
function loginPage(error=''){return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Repère · Accès privé</title><style>${css}</style></head><body><main class="card"><div class="brand">repère</div><h1>Votre espace privé</h1><p>Connectez-vous pour ouvrir Repère.</p>${error?`<p class="error" role="alert">${escape(error)}</p>`:''}<form action="/private/login" method="post"><label for="username">Identifiant Repère</label><input id="username" name="username" autocomplete="username" maxlength="80" required><label for="password">Mot de passe Repère</label><input id="password" name="password" type="password" autocomplete="current-password" maxlength="512" required><button>Ouvrir Repère</button></form><p class="foot">Utilisez les accès privés qui vous ont été communiqués. La connexion ÉcoleDirecte se fait ensuite dans l’application.</p></main></body></html>`;}

export async function createPrivateServer({origin,users,appFactory=()=>createAppServer(),now=()=>Date.now(),allowInsecureLocal=false}={}){
 const publicUrl=new URL(origin);
 if(publicUrl.origin!==origin||publicUrl.username||publicUrl.password||publicUrl.protocol!=='https:'&&!(allowInsecureLocal&&publicUrl.protocol==='http:'&&['127.0.0.1','localhost'].includes(publicUrl.hostname)))throw new Error('L’adresse publique doit être une origine HTTPS, sans chemin.');
 configuredUsers(Object.fromEntries(users.flatMap((u,i)=>[[`REPERE_USER_${i+1}`,u.name],[`REPERE_PASSWORD_${i+1}`,u.password]])));
 if(users.length!==2)throw new Error('Deux comptes sont requis.');
 const records=await Promise.all(users.map(async u=>{const salt=randomBytes(16);return {name:u.name,salt,hash:await scrypt(u.password,salt,64)};}));
 const sessions=new Map(),attempts=new Map();let busyChecks=0;
 const backends=new Map();
 try{for(const u of records){const backend=appFactory();backend.listen(0,'127.0.0.1');await once(backend,'listening');backends.set(u.name,backend);}}
 catch(error){for(const b of backends.values())b.close();throw error;}
 const secure=publicUrl.protocol==='https:',cookieName=secure?'__Host-repere_access':'repere_access_test';
 const accessCookie=(value,maxAge)=>`${cookieName}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure?'; Secure':''}`;
 function prune(){for(const [id,s] of sessions)if(s.until<=now())sessions.delete(id);for(const [key,values] of attempts){const recent=values.filter(v=>v>now()-600000);if(recent.length)attempts.set(key,recent);else attempts.delete(key);}}
 const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Robots-Tag','noindex, nofollow');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  if(secure)res.setHeader('Strict-Transport-Security','max-age=31536000');
  const html=(status,body)=>{res.writeHead(status,{'Content-Type':'text/html; charset=utf-8'});res.end(body);};
  const json=(status,message)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify({message}));};
  try{
   const path=new URL(req.url,origin).pathname;
   if(path==='/healthz'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'text/plain'});res.end('ok');return;}
   if(req.headers.host!==publicUrl.host){res.writeHead(403);res.end();return;}
   if(!['GET','HEAD','POST'].includes(req.method)){res.writeHead(405);res.end();return;}
   if(req.method==='POST'&&req.headers.origin!==origin){json(403,'Origine non autorisée.');return;}
   if(['cross-site'].includes(req.headers['sec-fetch-site'])&&path!=='/private/login'){res.writeHead(403);res.end();return;}
   prune();
   const sid=cookieValue(req.headers.cookie,cookieName),session=sessions.get(sid);
   if(path==='/private/login'){
    if(req.method==='GET'){if(session){res.writeHead(303,{Location:'/'});res.end();}else html(200,loginPage());return;}
    if(req.method!=='POST'){res.writeHead(405);res.end();return;}
    if(req.headers['content-type']?.split(';')[0]!=='application/x-www-form-urlencoded'){json(415,'Format non accepté.');return;}
    let body='';for await(const chunk of req){body+=chunk;if(body.length>8192){json(413,'Formulaire trop volumineux.');return;}}
    const form=new URLSearchParams(body),name=(form.get('username')||'').trim(),password=form.get('password')||'';
    const record=records.find(u=>u.name===name),key=record?'user:'+record.name:'unknown';
    const recent=attempts.get(key)||[],total=attempts.get('*')||[];
    if(recent.length>=10||total.length>=30||busyChecks>=2){res.setHeader('Retry-After','600');html(429,loginPage('Trop de tentatives. Réessayez dans dix minutes.'));return;}
    attempts.set(key,[...recent,now()]);attempts.set('*',[...total,now()]);
    if(password.length>512){html(401,loginPage('Identifiant ou mot de passe incorrect.'));return;}
    busyChecks++;let candidate;try{candidate=await scrypt(password,(record||records[0]).salt,64);}finally{busyChecks--;}
    if(!record||!timingSafeEqual(candidate,record.hash)){html(401,loginPage('Identifiant ou mot de passe incorrect.'));return;}
    if(sid)sessions.delete(sid);
    if(sessions.size>=100)sessions.delete(sessions.keys().next().value);
    const id=randomBytes(32).toString('hex');sessions.set(id,{name:record.name,until:now()+TTL});
    res.setHeader('Set-Cookie',[accessCookie(id,TTL/1000),`repere_session=; Path=/api; HttpOnly; SameSite=Strict; Max-Age=0${secure?'; Secure':''}`]);res.writeHead(303,{Location:'/'});res.end();return;
   }
   if(!session){if(path.startsWith('/api/')){json(401,'Votre accès privé a expiré. Rechargez la page pour vous reconnecter.');}else{res.writeHead(303,{Location:'/private/login'});res.end();}return;}
   const backend=backends.get(session.name),target=`http://127.0.0.1:${backend.address().port}`;
   if(path==='/private/logout'){
    if(req.method!=='POST'){res.writeHead(405);res.end();return;}
    sessions.delete(sid);
    try{await fetch(target+'/api/logout',{method:'POST',headers:{Origin:target,'Content-Type':'application/json','X-Repere-Request':'1',Cookie:req.headers.cookie||''},body:'{}',signal:AbortSignal.timeout(2000)});}catch{}
    res.setHeader('Set-Cookie',[accessCookie('',0),`repere_session=; Path=/api; HttpOnly; SameSite=Strict; Max-Age=0${secure?'; Secure':''}`]);res.setHeader('Clear-Site-Data','"cache"');res.writeHead(303,{Location:'/private/login'});res.end();return;
   }
   // All upstreams are fixed, isolated loopback servers: no user-controlled destination.
   const headers={...req.headers,host:new URL(target).host};
   for(const key of ['forwarded','x-forwarded-host','x-forwarded-proto','x-forwarded-for','authorization','connection','transfer-encoding','upgrade'])delete headers[key];
   if(req.headers.origin)headers.origin=target;
   const proxy=http.request(target+req.url,{method:req.method,headers},upstream=>{
    const responseHeaders={...upstream.headers};delete responseHeaders.connection;delete responseHeaders['transfer-encoding'];
    if(responseHeaders['set-cookie'])responseHeaders['set-cookie']=responseHeaders['set-cookie'].map(c=>secure&&!/;\s*Secure/i.test(c)?c+'; Secure':c);
    for(const [key,value] of Object.entries(responseHeaders))if(value!==undefined)res.setHeader(key,value);
    if((path==='/'||path==='/index.html')&&req.method==='GET'&&upstream.statusCode===200){
     let page='';upstream.setEncoding('utf8');upstream.on('data',chunk=>page+=chunk);upstream.on('end',()=>{
      const bar=`<style>.private-account{position:fixed;bottom:14px;right:14px;z-index:40;display:flex;gap:12px;align-items:center;background:#fff;border:1px solid #dce4d6;border-radius:7px;padding:9px 12px;font:12px system-ui;color:#355346;box-shadow:0 2px 12px #183b3a12}.private-account button{border:0;background:none;color:#244d43;text-decoration:underline;cursor:pointer;font:inherit}.private-account form{margin:0}.footer{padding-bottom:65px}</style><aside class="private-account" aria-label="Compte privé"><span>${escape(session.name)}</span><form action="/private/logout" method="post"><button>Quitter l’espace privé</button></form></aside>`;
      res.removeHeader('Content-Length');res.writeHead(200);res.end(page.replace('</body>',bar+'</body>'));
     });
    }else{res.writeHead(upstream.statusCode||502);upstream.pipe(res);}
    upstream.on('error',()=>res.destroy());
   });
   proxy.setTimeout(300000,()=>proxy.destroy());
   proxy.on('error',()=>{if(!res.headersSent)json(502,'Le service est momentanément indisponible.');else res.end();});
   req.on('aborted',()=>proxy.destroy());res.on('close',()=>{if(!res.writableEnded)proxy.destroy();});req.pipe(proxy);
  }catch{if(!res.headersSent)json(500,'Impossible de terminer la demande.');else res.end();}
 });
 server.requestTimeout=300000;server.headersTimeout=15000;
 server.on('close',()=>{sessions.clear();for(const backend of backends.values()){backend.closeAllConnections();backend.close();}});
 return server;
}
