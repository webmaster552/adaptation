// Preserve every received event; the four-week counters are a separate view.
const plain=value=>String(value??'').normalize('NFD').replace(/\p{Diacritic}/gu,'').replace(/[‐‑–—]/g,'-').toLowerCase();
const months=['janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre','decembre'];
export function displayDates(value){
 const out=[];
 for(const match of plain(value).matchAll(/\b(\d{1,2})(?:er)?\s+(janvier|fevrier|mars|avril|mai|juin|juillet|aout|septembre|octobre|novembre|decembre)\s+(\d{4})\b/g)){
  const date=`${match[3]}-${String(months.indexOf(match[2])+1).padStart(2,'0')}-${match[1].padStart(2,'0')}`;
  const t=Date.parse(date+'T12:00:00Z');if(Number.isFinite(t)&&new Date(t).toISOString().slice(0,10)===date)out.push(date);
 }
 return out;
}
export function durationHalfDays(item,number){
 for(const key of ['nbDemiJournees','nombreDemiJournees'])if(item[key]!==undefined){const value=number(item[key]);return Number.isInteger(value)&&value>=0?value:null;}
 const label=plain(item.libelle).trim().replace(/\(s\)/g,'s');
 const m=label.match(/^(\d+)\s+demi[ -]?journees?\s*$/);if(m)return Number(m[1]);
 return /^(?:une|1\/2|½)\s+(?:demi[ -]?)?journee$/.test(label)&&/demi|1\/2|½/.test(label)?1:null;
}
export function attendanceDetails(data,periods,{dateOnly,number}){
 const empty={absenceHalfDays:null,justifiedHalfDays:null,lates:null,absenceEvents:null,justifiedEvents:null,events:[],warnings:['La vie scolaire n’a pas été transmise.']};
 if(!Array.isArray(data?.absencesRetards))return empty;
 const values={absenceHalfDays:0,justifiedHalfDays:0,lates:0,absenceEvents:0,justifiedEvents:0},unknown=new Set(),events=[],warnings=[],seen=new Set();
 const flag=(keys,message)=>{keys.forEach(k=>unknown.add(k));warnings.push(message);};
 const absenceKeys=['absenceHalfDays','justifiedHalfDays','absenceEvents','justifiedEvents'];
 for(const item of data.absencesRetards){
  const type=plain(item.typeElement).trim();if(!['absence','retard'].includes(type))continue;
  const key=`${type}-${item.id??JSON.stringify([item.date,item.displayDate,item.libelle])}`;if(seen.has(key))continue;seen.add(key);
  const displayed=displayDates(item.displayDate),start=dateOnly(item.date)||displayed[0],end=dateOnly(item.dateFin)||displayed.at(-1)||null;
  const halfDays=durationHalfDays(item,number);
  const normalized=plain(item.justifie),justified=item.justifie===true||normalized==='1'||normalized==='true'||normalized==='oui'?true:item.justifie===false||normalized==='0'||normalized==='false'||normalized==='non'?false:null;
  events.push({id:String(key),kind:type==='retard'?'late':'absence',date:start||null,endDate:end,halfDays:type==='absence'?halfDays:null,justified,durationLabel:String(item.libelle||'').slice(0,200),displayDate:String(item.displayDate||'').slice(0,300),justificationLabel:String(item.typeJustification||'').slice(0,200)});
  if(!start){flag(type==='retard'?['lates']:absenceKeys,'Certains événements n’ont pas de date utilisable.');continue;}
  if(start>periods.recentEnd)continue;
  if(start<periods.recentStart){if(type==='absence'&&(end?end>=periods.recentStart:halfDays>2))flag(absenceKeys,'Une absence chevauche la période affichée. Son détail reste disponible dans ÉcoleDirecte.');continue;}
  if(type==='retard'){values.lates++;continue;}
  if(justified===null){flag(absenceKeys,'La justification de certaines absences n’a pas été transmise.');continue;}
  const daysKey=justified?'justifiedHalfDays':'absenceHalfDays',eventKey=justified?'justifiedEvents':'absenceEvents';values[eventKey]++;
  if(halfDays===null){flag([daysKey],'Certaines absences sont données en heures. Leur durée est affichée sans la convertir en demi-journées.');continue;}
  if((end&&end>periods.recentEnd)||(!end&&halfDays>2)){flag([daysKey],'La répartition d’une absence sur plusieurs jours n’a pas été transmise.');continue;}
  values[daysKey]+=halfDays;
 }
 for(const key of unknown)values[key]=null;
 return {...values,events,warnings:[...new Set(warnings)]};
}
