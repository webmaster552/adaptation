"""Package the demo as one HTML file; no server needed to open it.

Les modules de dist/ sont regroupés avec esbuild (outil de construction
uniquement : npx le télécharge au besoin, rien à installer pour utiliser le site).
Usage : python3 build_standalone.py [Repere.html]
"""
from pathlib import Path
import base64
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
out = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / 'Repere.html'
dist = root / 'dist'

npx = shutil.which('npx')
if not npx:
    sys.exit('npx est introuvable : installez Node.js (https://nodejs.org/) pour reconstruire Repere.html.')
bundle = subprocess.run(
    [npx, '--yes', 'esbuild', str(dist / 'app.js'), '--bundle', '--format=iife', '--external:https://*', '--target=es2022'],
    check=True, capture_output=True, text=True, cwd=root,
).stdout

html = (dist / 'index.html').read_text(encoding='utf-8')
css = (dist / 'styles.css').read_text(encoding='utf-8')
js = bundle
assets = [
    ('portraits-fictifs.png', 'image/png'), ('favicon.svg', 'image/svg+xml'),
    ('logo-yabne.png', 'image/png'), ('logo-yabne-blanc.png', 'image/png'),
    ('hero-corps.png', 'image/png'), ('hero-flamme-g.png', 'image/png'), ('hero-flamme-d.png', 'image/png'),
]
for file, mime in assets:
    data = f'data:{mime};base64,' + base64.b64encode((dist / 'assets' / file).read_bytes()).decode('ascii')
    css = css.replace(f'assets/{file}', data)
    html = html.replace(f'assets/{file}', data)
    js = js.replace(f'assets/{file}', data)
# Le fichier autonome fonctionne hors ligne : polices système uniquement.
css = re.sub(r"@import url\([^\n]+\);\n", '', css, count=1)
js = js.replace('</script', '<\\/script')
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>\n' + css + '\n</style>')
html = html.replace('<script type="module" src="app.js"></script>', '<script>\n' + js + '\n</script>')
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(html, encoding='utf-8')
print(f'Standalone HTML: {out.name} ({out.stat().st_size:,} bytes)')
