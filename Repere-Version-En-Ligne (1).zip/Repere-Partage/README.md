# Repère — version à partager

Copie indépendante de la version locale du 21 octobre 2026.

## Habillage Yabne

Le site s'ouvre sur une page de connexion aux couleurs du logo Yabne (`dist/assets/logo-yabne*.png`, `hero-*.png`). L'identifiant ÉcoleDirecte détermine l'espace : élève ou parent → interface élève, professeur → interface professeur. Les boutons « Aperçu » ouvrent la démonstration à données fictives. Le thème se trouve à la fin de `dist/styles.css` (variables `--brand`, `--gold`, `--navy`). `Repere.html` se reconstruit avec `python3 build_standalone.py`.

## Render

Service web Node.js, plan Free. Construction : `npm test`. Démarrage : `npm run start:render`. L’origine HTTPS est fournie automatiquement par `RENDER_EXTERNAL_URL`. `/healthz` répond sans connexion.

Aucun mot de passe ni dossier scolaire personnel n’est inclus dans ce dépôt. Chaque visiteur peut explorer les données fictives ou se connecter à son propre compte ÉcoleDirecte. Ses accès restent limités aux dossiers autorisés. Les protections et confirmations ÉcoleDirecte restent applicables.

## Assistant

Le modèle Qwen3-4B est exécuté dans le navigateur, après un téléchargement initial d’environ 3 Go. Un ordinateur disposant de WebGPU et de mémoire suffisante est nécessaire. La disponibilité de l’IA sur téléphone dépend de l’appareil et du navigateur. Les pages ordinaires restent utilisables sans le modèle.

La lecture des photos utilise Tesseract sur l’appareil ; elle est surtout adaptée aux textes imprimés. Elle n’offre pas la même lecture manuscrite que le moteur multimodal de la version Mac. Les ateliers élèves et professeurs, fiches, questions et supports de cours utilisent le moteur du navigateur.

Les cours, transcriptions et préparations sont conservés dans le navigateur de leur propriétaire, pas partagés avec les autres visiteurs. Utiliser les exports pour les sauvegarder. Les sessions ÉcoleDirecte restent en mémoire du serveur et expirent ; un redémarrage nécessite une reconnexion.

Le plan gratuit Render est destiné aux essais, avec veille après inactivité et quotas partagés. Ce déploiement n’est pas une offre illimitée pour toute une école. Aucun abonnement IA payant n’est activé.

## Vérification

`npm test` utilise des données fictives. Il ne se connecte à aucun compte scolaire réel.
