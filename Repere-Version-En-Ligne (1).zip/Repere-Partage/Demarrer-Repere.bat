@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Installez Node.js 22 ou plus recent depuis https://nodejs.org/
  echo Puis relancez ce fichier.
  pause
  exit /b 1
)
node start.mjs
set "repere_result=%ERRORLEVEL%"
if not "%repere_result%"=="0" pause
exit /b %repere_result%
